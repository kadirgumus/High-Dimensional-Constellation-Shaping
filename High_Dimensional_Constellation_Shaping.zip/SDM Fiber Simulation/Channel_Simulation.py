#%%Importing packages 
import numpy as np
# import cupy as np
import matplotlib.pyplot as plt
# from Helper_Functions import *
import Functions.Helper_Functions as hf
 #%% Simulating MI
 #System Parameters
Nbits = 10**4 #Number of information bits to be simulated per mode
Kcode = 10**4 #Number of information bits per codeword per mode
Rcode = 0.5 #The code rate of the used code
Ncode = int(Kcode/Rcode) #The blocklength of the code
SNR = np.arange(10,30,1) #The signal to noise ratio of the complex channel
D = 2 #The amount of modes (each polarization counts as a seperate mode)
symbols_per_dimension = 2**1
X = hf.Generate_ND_PAM(2*D,symbols_per_dimension)
# X = hf.Generate_PSK(symbols_per_dimension**(2*D))
H_realizations = 1

#Generation of signal 
MI = np.zeros((np.size(SNR),H_realizations))
MDL_S = 10**(0/10)
sigma_MDL = 0
for j in range(H_realizations):
    # H = hf.Generate_V_Matrix(D,MDL_S)
    # H = hf.Generate_Transfer_Matrix(D)
    H = np.eye(D)
    # Q = hf.Generate_Q(D)
    # eig = hf.get_MDL_CSI(Q,D)
    # g = eig*sigma_MDL
    # H = np.diag(np.exp(0.5*g))
    # H = np.sqrt(D)*H/np.sqrt(np.sum(H**2))
    for i in range(np.size(SNR)):
        c = np.random.randint(2,size = (int(Ncode/H_realizations),D))#The codeword bitstream, for now we do not implement encoding
        x = hf.Modulation(c,X,D)
        y_H = hf.Channel_Matrix(H,x)
        y = hf.AWGN_channel(y_H,SNR[i],X)
        MI[i,j] = hf.MI_calc(x,y,D)
MI = np.mean(MI,1)
plt.semilogy(SNR,MI)

#%% Simulating BER
Nsymbols_loop = 10**4
loops = 10
SNR = np.arange(7.5,8.5,0.2) #The signal to noise ratio of the complex channel
D = 4 #The amount of real dimensions
# Data = np.load('Data/GMI/2D/64/GMI_OW_2D_64_15dB_0.1lrAPSK_4Rings.npy',allow_pickle=True)
# Data = np.load('Data/GMI/4D/4096/GMI_OW_4D_4096_15dB_0.1lrAPSK_4Rings.npy',allow_pickle=True)
Data = np.load('Data/GMI/4D/64/GMI_OW_4D_64_8dB_0.1lrAPSK_2Rings.npy',allow_pickle=True)
# Data = np.load('Data/GMI/8D/4096/GMI_OW_8D_4096_8dB_0.1lrOptimized.npy',allow_pickle=True)
# Data = np.load('Data/GMI/4D/8192/GMI_OW_4D_8192_16dB_0.1lrAPSK_13bit.npy',allow_pickle=True)
# Data = np.load('Data/GMI/8D/256/GMI_OW_8D_256_4dB_0.1lrAPSK_1Rings.npy',allow_pickle=True)
# Data = np.load('Data/GMI/12D/2048/GMI_OW_12D_2048_4dB_0.1lrBPSK_11bit.npy', allow_pickle = True)
# Data = np.load('Data/GMI/4D/4096/GMI_OW_4D_4096_15dB_0.1lrAPSK_4Rings.npy', allow_pickle = True)
# Data = np.load('Data/GMI/4D/8192/GMI_OW_4D_8192_16dB_0.1lrEric.npy', allow_pickle = True)
# Data = np.load('Data/GMI/4D/4096/GMI_OW_4D_4096_15dB_0.1lrOptimized.npy', allow_pickle = True)
# X = hf.Generate_ND_PAM(D,8)
X = Data[0][:,:,-1]
idx = Data[2]
# [X,idx]= get_APSK(64,4)
# [X,idx]= get_constellation(4)
X = np.loadtxt('Data/Eric_4D/opt8db_64.txt', delimiter=',')
idx = np.arange(np.size(X,0))
idx2 = np.zeros(np.size(X,0),dtype = int)
for i in range(np.size(X,0)):
    idx2[idx[i]] = i 
X = X[idx2,:]
X = hf.normalization_np(X, D)
m = int(np.log2(np.size(X,0)))

#Generation of signal 
BER = np.zeros(np.size(SNR))
SER = np.zeros(np.size(SNR))
for j in range(loops):
    for i in range(np.size(SNR)):
        c = np.random.randint(2,size = (int(Nsymbols_loop),m))#The codeword bitstream
        x = hf.Modulation_general(c,X)
        y = hf.AWGN_channel_general(x, 1/(D*10**(SNR[i]/10)))
        c_hat,x_hat = hf.Demodulation_general(y, X,x)
        BER[i] = hf.BER_calc(c, c_hat) + BER[i]
        SER[i] = hf.SER_calc(x,x_hat) + SER[i]
EbN0 = SNR - 10*np.log10(m)
BER = BER/(Nsymbols_loop*loops*m)
SER = SER/(Nsymbols_loop*loops)
plt.semilogy(EbN0,BER, EbN0, SER)
  # %%Simulating Capacity assuming no MDL or crosstalk (Kuang-Po Ho)
rho_t = np.arange(-5,20,0.1);
D = 2**np.arange(6);
C = np.zeros((np.size(rho_t,0), np.size(D,0)))
for i in range(np.size(rho_t,0)):
    for j in range(np.size(D,0)):
        C[i,j] = hf.Capacity_MMF(rho_t[i],D[j])
        
#%% Simulating Capacity assuming MDL (Kuang-Po Ho) for a range of MDL
gamma = 4.34
rho_t = 10
xi = np.arange(0,20,0.1)/gamma
D = np.array([2,4,8,16,64,512])
C = np.zeros((np.size(xi,0),np.size(D,0)))
for j in range(np.size(D,0)):
    for i in range(np.size(xi,0)):
        sigma_MDL = hf.sigma_MDL_calc(xi[i])
        stepsize = 0.01
        x = np.arange(-3,3,stepsize)
        PDF = hf.MDL_dist(x,D[j])
        chi = hf.chi_calc(rho_t,sigma_MDL,PDF,x,stepsize,D[j])
        C[i,j] = hf.Capacity_MMF_MDL(chi,D[j],x,PDF,sigma_MDL,stepsize)
    plt.plot(xi*gamma,C[:,j]);
plt.show()

#%% Simulating Capacity assuming MDL (Kuang-Po Ho) for a range of SNR
SNR = np.arange(-10,25,0.1)
D = 2
sigma_MDL = 1
C = np.zeros(np.size(SNR,0))
for j in range(np.size(SNR,0)):
    rho_t = 10**(SNR[j]/10)/2
    stepsize = 0.01
    x = np.arange(-3,3,stepsize)
    PDF = hf.MDL_dist(x,D)
    chi = hf.chi_calc(rho_t,sigma_MDL,PDF,x,stepsize,D)
    C[j] = hf.Capacity_MMF_MDL(chi,D,x,PDF,sigma_MDL,stepsize)
plt.plot(SNR,C);
#%% Simulating Capacity Assuming MDL and CSI (Kuang-Po Ho)
D = 16
gamma = 4.34
iterations = 1000
xi = np.arange(0,20,0.1)/gamma
C = np.zeros((iterations,np.size(xi,0)))
for j in range(np.size(xi,0)):
    for i in range(iterations):
        Q = hf.Generate_Q(D)
        eig = hf.get_MDL_CSI(Q,D)
        sigma_MDL = hf.sigma_MDL_calc(xi[j])
        rho_t = 10
        stepsize = 0.01
        x = np.arange(-3,3,stepsize)
        PDF = hf.MDL_dist(x,D)
        chi = hf.chi_calc(rho_t,sigma_MDL,PDF,x,stepsize,D)
        mu = hf.calc_mu(chi,eig*sigma_MDL,D)
        C[i,j] = hf.Capacity_MMF_MDL_CSI(mu,eig*sigma_MDL,D)

#%% Calculate Capacity assuming no MDL and different amount of transceivers and receivers (Peter Winzer)
D = np.array([4,8,16,32,64])
E0N0 = 100
Mt = np.array([1,2,3,4,8,16,32,64])
Mr = np.array([1,2,3,4,8,16,32,64])
L = 1
Cs = hf.Capacity_MMF(E0N0,1)
iterations = 100000
data = np.zeros((np.size(D),np.size(Mt)))
for j in range(np.size(D)):
    for k in range(np.size(Mt)):
        if(Mt[k] < D[j]):
            C = np.zeros(iterations)
            for i in range(iterations):
                H = hf.Generate_Transfer_Matrix(D[j])
                labda,eigvec = np.linalg.eigh(H[:Mt[k],:Mr[k]].dot(H[:Mt[k],:Mr[k]].conj().T))
                C[i] = hf.Capacity_MMF_MDL_Winzer(labda,E0N0,1)
            Pout = np.zeros(32000)
            for i in range(32000):
                Pout[i] = hf.Pout_calc(C,Cs*(0+0.001*i))
            data[j,k] = np.count_nonzero(Pout<0.0001)*0.001
        elif(Mt[k] == D[j]):
            data[j,k] = D[j]

#%% Calculate Capacity assuming MDL and crosstalk (Peter Winzer)
D = 6
K = 1
MDL_S = 10**(0/10)
E0N0 = (10**(np.arange(-7,18,0.4)/10))/D
iterations = 1000
Cs_all = np.zeros(iterations)
l_mean = np.zeros(iterations)
MDL_sigma = np.zeros(iterations)
C = np.zeros(iterations)
C_mean = np.zeros(np.size(E0N0))
for k in range(np.size(E0N0)):
    for j in range(iterations):
        for i in range(K):
            H = np.eye(D)
            # H = hf.Generate_Transfer_Matrix(D)
            V = hf.Generate_V_Matrix(D,MDL_S)
            if(i == 0):
                H_total = H
            else:
                H_total = H_total.dot(H)
            H_total = H_total.dot(V)
        labda,eigvec = np.linalg.eigh(H_total.dot(H_total.conj().T))
        L = np.real(np.trace(H_total.dot(H_total.conj().T))/D)
        C[j] = hf.Capacity_MMF_MDL_Winzer(labda,E0N0[k],L)
        l_mean[j] = L
        MDL_sigma[j] = np.amax(labda)/np.amin(labda)
        Cs_all[j] = hf.Capacity_MMF(E0N0[k],L)
    Cs = np.mean(Cs_all)
    C_mean[k] = np.mean(C)