import numpy as np
import cupy as cp

#%% The GMI MC approximation function
def GMI_MC_Numpy(X,idx,EsN0_dB,samples):
    #Setting up variables
    M = int(np.size(X,0))
    m = int(np.log2(M))
    channel_uses = np.size(X,1)
    idx2 = np.zeros(M, dtype = int)
    for i in range(M):
        idx2[idx[i]] = i 
    X = X[idx2,:]
    X = normalization_np(X,channel_uses)
    
    #Determining the labeling
    labeling =de2bi(np.arange(M),m)
    Ik1 = np.zeros([int(M/2),int(m)],dtype = int) #Find the pointers to the subconstellations
    Ik0 = np.zeros([int(M/2),int(m)],dtype = int)
    for kk in range(int(m)): 
        Ik1[:,kk] = np.where(labeling[:,kk] == 1)[0]
        Ik0[:,kk] = np.where(labeling[:,kk] == 0)[0]
        
    #Calculating distances between points
    Dmat = np.zeros((M,M,channel_uses))
    for i in range(channel_uses):
        Dmat[:,:,i] = np.expand_dims(X[:,i],1) - np.expand_dims(X[:,i],1).T #Calculate the distances between constellation points
    
    dip0 = np.zeros((int(M/2),M,channel_uses,m))
    dip1 = np.zeros((int(M/2),M,channel_uses,m))
    dij0 = np.zeros((int(M/2),int(M/2),channel_uses,m))
    dij1 = np.zeros((int(M/2),int(M/2),channel_uses,m))
    for i in range(m):
        dip0[:,:,:,i] = Dmat[Ik0[:,i],:,:]
        dip1[:,:,:,i] = Dmat[Ik1[:,i],:,:]
        dij0[:,:,:,i] = dip0[:,Ik0[:,i],:,i]
        dij1[:,:,:,i] = dip1[:,Ik1[:,i],:,i]
    
    dip0norm = np.sum(dip0**2,2)
    dip1norm = np.sum(dip1**2,2)
    dij0norm = np.sum(dij0**2,2)
    dij1norm = np.sum(dij1**2,2)
    
    #Calculating SNR variables
    Es = np.sum(X**2,1).mean() #Calculate the signal energy
    EsN0lin = 10**(EsN0_dB/10)  #Turn the SNR value from dB to a linear value
    SigmaZ2 = (Es/(EsN0lin)) #Calculate the noise 
    
    #Setting up GMI
    z = np.random.normal(0,np.sqrt(SigmaZ2/channel_uses),(int(M/2),1,channel_uses,samples))
    z[:,1:2:-1] = z[:,1:2:-1]*-1
    
    sum0 = 0
    sum1 = 0
    #Calculating GMI
    for i in range(samples):
        num0 = np.sum(np.exp((-(dip0norm+2*np.sum(z[:,:,:,[i]]*dip0,2)))/(2*SigmaZ2/channel_uses)),1)
        num1 = np.sum(np.exp((-(dip1norm+2*np.sum(z[:,:,:,[i]]*dip1,2)))/(2*SigmaZ2/channel_uses)),1)
        den0 = np.sum(np.exp((-(dij0norm+2*np.sum(z[:,:,:,[i]]*dij0,2)))/(2*SigmaZ2/channel_uses)),1)
        den1 = np.sum(np.exp((-(dij1norm+2*np.sum(z[:,:,:,[i]]*dij1,2)))/(2*SigmaZ2/channel_uses)),1)
        sum0 = sum0+np.sum(np.log2(num0/den0))
        sum1 = sum1+np.sum(np.log2(num1/den1))
    GMI = m-(sum0+sum1)/(M*samples)
    return GMI

def GMI_MC_Cupy2(X,idx,EsN0_dB,samples):
    #Setting up variables
    M = int(np.size(X,0))
    m = int(np.log2(M))
    channel_uses = np.size(X,1)
    idx2 = np.zeros(M, dtype = int)
    for i in range(M):
        idx2[idx[i]] = i 
    X = X[idx2,:]
    X = normalization_cp(X,channel_uses)
    
    #Determining the labeling
    labeling =de2bi(np.arange(M),m)
    Ik1 = np.zeros([int(M/2),int(m)],dtype = int) #Find the pointers to the subconstellations
    Ik0 = np.zeros([int(M/2),int(m)],dtype = int)
    for kk in range(int(m)): 
        Ik1[:,kk] = np.where(labeling[:,kk] == 1)[0]
        Ik0[:,kk] = np.where(labeling[:,kk] == 0)[0]
        
    #Calculating distances between points
    Dmat = cp.zeros((M,M,channel_uses))
    for i in range(channel_uses):
        Dmat[:,:,i] = cp.expand_dims(X[:,i],1) - cp.expand_dims(X[:,i],1).T #Calculate the distances between constellation points
    
    dip0 = cp.zeros((int(M/2),M,channel_uses,m))
    dip1 = cp.zeros((int(M/2),M,channel_uses,m))
    dij0 = cp.zeros((int(M/2),int(M/2),channel_uses,m))
    dij1 = cp.zeros((int(M/2),int(M/2),channel_uses,m))
    for i in range(m):
        dip0[:,:,:,i] = Dmat[Ik0[:,i],:,:]
        dip1[:,:,:,i] = Dmat[Ik1[:,i],:,:]
        dij0[:,:,:,i] = dip0[:,Ik0[:,i],:,i]
        dij1[:,:,:,i] = dip1[:,Ik1[:,i],:,i]
    
    dip0norm = cp.sum(dip0**2,2)
    dip1norm = cp.sum(dip1**2,2)
    dij0norm = cp.sum(dij0**2,2)
    dij1norm = cp.sum(dij1**2,2)
    
    #Calculating SNR variables
    Es = cp.sum(X**2,1).mean() #Calculate the signal energy
    EsN0lin = 10**(EsN0_dB/10)  #Turn the SNR value from dB to a linear value
    SigmaZ2 = (Es/(EsN0lin)) #Calculate the noise 
    
    #Setting up GMI
    z = cp.random.normal(0,np.sqrt(SigmaZ2/channel_uses),(int(M/2),1,channel_uses,samples))
    z[:,:,1:2:-1,:] = z[:,:,1:2:-1,:]*-1
    
    sum0 = 0
    sum1 = 0
    #Calculating GMI
    for i in range(samples):
        num0 = cp.sum(cp.exp((-(dip0norm+2*cp.sum(z[:,:,:,[i]]*dip0,2)))/(2*SigmaZ2/channel_uses)),1)
        num1 = cp.sum(cp.exp((-(dip1norm+2*cp.sum(z[:,:,:,[i]]*dip1,2)))/(2*SigmaZ2/channel_uses)),1)
        den0 = cp.sum(cp.exp((-(dij0norm+2*cp.sum(z[:,:,:,[i]]*dij0,2)))/(2*SigmaZ2/channel_uses)),1)
        den1 = cp.sum(cp.exp((-(dij1norm+2*cp.sum(z[:,:,:,[i]]*dij1,2)))/(2*SigmaZ2/channel_uses)),1)
        sum0 = sum0+cp.sum(cp.log2(num0/den0))
        sum1 = sum1+cp.sum(cp.log2(num1/den1))
    GMI = m-(sum0+sum1)/(M*samples)
    return GMI

def AIR_MC_Cupy(X,idx,EsN0_dB,samples):
    #Setting up variables
    M = int(np.size(X,0))
    m = int(np.log2(M))
    channel_uses = np.size(X,1)
    idx2 = np.zeros(M, dtype = int)
    for i in range(M):
        idx2[idx[i]] = i 
    X = X[idx2,:]
    X = normalization_cp(X,channel_uses)
    
    #Determining the labeling
    labeling =de2bi(np.arange(M),m)
    Ik1 = np.zeros([int(M/2),int(m)],dtype = int) #Find the pointers to the subconstellations
    Ik0 = np.zeros([int(M/2),int(m)],dtype = int)
    for kk in range(int(m)): 
        Ik1[:,kk] = np.where(labeling[:,kk] == 1)[0]
        Ik0[:,kk] = np.where(labeling[:,kk] == 0)[0]
        
    #Calculating distances between points
    Dmat = cp.zeros((M,M,channel_uses))
    for i in range(channel_uses):
        Dmat[:,:,i] = cp.expand_dims(X[:,i],1) - cp.expand_dims(X[:,i],1).T #Calculate the distances between constellation points
    
    Dmatnorm = cp.sum(Dmat**2,2)
    
    #Calculating SNR variables
    Es = cp.sum(X**2,1).mean() #Calculate the signal energy
    EsN0lin = 10**(EsN0_dB/10)  #Turn the SNR value from dB to a linear value
    SigmaZ2 = (Es/(EsN0lin)) #Calculate the noise 
    
    #Setting up GMI
    z = cp.random.normal(0,np.sqrt(SigmaZ2/channel_uses),(channel_uses,samples))
    z[1:2:-1,:] = z[1:2:-1,:]*-1
    
    sum0 = 0
    sum1 = 0
    sum_temp = 0
    #Calculating GMI
    for i in range(samples):
        num = cp.exp((-(Dmatnorm+2*cp.sum(z[:,i]*Dmat,2)))/(2*SigmaZ2/channel_uses))
        for k in range(m):
            num0 = num[Ik0[:,k],:]
            num1 = num[Ik1[:,k],:]
            den0 = num0[:,Ik0[:,k]]
            den1 = num1[:,Ik1[:,k]]
            sum0 = sum0+cp.sum(cp.log2(cp.sum(num0,1)/cp.sum(den0,1)))
            sum1 = sum1+cp.sum(cp.log2(cp.sum(num1,1)/cp.sum(den1,1)))
        sum_temp = sum_temp + cp.sum(cp.log2(cp.sum(num,1)))
    GMI = m-(sum0+sum1)/(M*samples)
    MI = m - sum_temp/(M*samples)
    return GMI,MI

def MI_MC_Cupy(X,EsN0_dB,samples):
    #Setting up variables
    M = int(np.size(X,0))
    m = int(np.log2(M))
    channel_uses = np.size(X,1)
    X = normalization_cp(X,channel_uses)

        
    #Calculating distances between points
    Dmat = cp.zeros((M,M,channel_uses))
    for i in range(channel_uses):
        Dmat[:,:,i] = cp.expand_dims(X[:,i],1) - cp.expand_dims(X[:,i],1).T #Calculate the distances between constellation points
    
    Dmatnorm = cp.sum(Dmat**2,2)
    
    #Calculating SNR variables
    Es = cp.sum(X**2,1).mean() #Calculate the signal energy
    EsN0lin = 10**(EsN0_dB/10)  #Turn the SNR value from dB to a linear value
    SigmaZ2 = (Es/(EsN0lin)) #Calculate the noise 
    
    #Setting up GMI
    z = cp.random.normal(0,np.sqrt(SigmaZ2/channel_uses),(channel_uses,samples))
    z[1:2:-1,:] = z[1:2:-1,:]*-1
    
    sum0 = 0
    sum1 = 0
    sum_temp = 0
    #Calculating GMI
    for i in range(samples):
        num = cp.exp((-(Dmatnorm+2*cp.sum(z[:,i]*Dmat,2)))/(2*SigmaZ2/channel_uses))
        # num = cp.exp((-(cp.sum(Dmat**2,2)+2*cp.sum(z[:,i]*Dmat,2)))/(2*SigmaZ2/channel_uses))
        sum_temp = sum_temp + cp.sum(cp.log2(cp.sum(num,1)))
    MI = m - sum_temp/(M*samples)
    return MI
#%%Debugging
plt.plot(X[:,0],X[:,1],'.', ms = 20, color = 'tab:red')
plt.axis([-0.4,0.4,-0.4,0.4])
plt.axis('off')
plt.savefig('4D_16_12.png', transparent = True)
plt.show()