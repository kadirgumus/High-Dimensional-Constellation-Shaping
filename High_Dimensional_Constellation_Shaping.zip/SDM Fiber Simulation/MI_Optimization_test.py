#%%Importing the required packages
import torch as tr
import numpy as np
# import cupy as cp
import scipy.io as sio
import math
import time
import sys
import Functions.Helper_Functions as hf
import matplotlib.pyplot as plt
#%%Defining some of the functions used
def awgn_channel(x,sigmaZ2):
    samples = cp.size(x,0)
    channel_uses = cp.size(x,1)
    return x + cp.sqrt(sigmaZ2)*cp.random.normal(size = (samples,channel_uses))

def normalization(x): # E[|x|^2] = 1
    return tr.sqrt((channel_uses*(x**2)).mean())

def normalization2(x):
    return x/tr.sqrt((channel_uses*(x**2)).mean())

def normalization_np(x,D):
    return x / np.sqrt((D*(x**2)).mean())

def normalization_cp(x,D):
    return x / cp.sqrt((D*(x**2)).mean())

def save():
        np.save('./Data/MI/' + str(channel_uses) + 'D/' + str(M) + '/MI_' + Estimation_type + '_' + str(channel_uses) + 'D_' + str(M) + '_' + str(EsNo_dB) + 'dB_'+ str(learning_rate)+'lr', [
          Constellations,
          EsNo_dB,
          epochs,
          learning_rate,
          Device,
          time.time()-start_time], allow_pickle=True)

def Weight_Rotation_Random(Weights,M):
    M = int(M)
    m = int(np.log2(M))
    D_complex = int((Weights.size(1)-1)/2)
    W = tr.zeros(Weights.size(0),Weights.size(1),m).to(Device)
    angles = tr.pi/2*tr.rand(m,D_complex)
    for i in range(m):
        for j in range(D_complex):
            W[:,2*j,i] = Weights[:,2*j] * tr.cos(angles[i,j]) - Weights[:,2*j+1] * tr.sin(angles[i,j])
            W[:,2*j+1,i] = Weights[:,2*j+1] * tr.cos(angles[i,j]) + Weights[:,2*j] * tr.sin(angles[i,j])
        W[:,-1,i] = Weights[:,-1]
    return W

def Weight_initialization(Weight_Amount, channel_uses):
    xi = np.random.normal(0,1,(Weight_Amount,channel_uses))
    alpha = np.exp(-np.sum(xi**2,1)/2)
    return np.column_stack((xi,alpha))
#%% Build the computation graph
def MI_MC_Cupy(X,EsNo_dB,samples):
    M = cp.size(X,0)
    m = cp.log2(M)
    channel_uses = cp.size(X,1)
    X = normalization_cp(X,channel_uses)
    x_idx = cp.random.randint(low = 0, high = M, size = samples)
    x = X[x_idx,:]
    sigmaZ2 = 1/(channel_uses*10**(EsNo_dB/10))
    y = awgn_channel(x,sigmaZ2)                

    # compute posterior distribution
    xx = cp.repeat(cp.expand_dims(X,1),samples,1)
    yy = cp.repeat(cp.expand_dims(y,0),M,0)

    num = cp.exp(-cp.sum((y-x)**2,1)/(2*sigmaZ2)) # f_{Y|X}
    den = cp.exp(-cp.sum((yy-xx)**2,2)/(2*sigmaZ2)).mean(0) # f_{Y}

    posterior = num/den

    MI = (cp.log(posterior)/cp.log(2)).mean()
    return MI

def MI_GH_Numpy(X_tilde,EsNo_dB):
    X = normalization_np(X_tilde,2) 
    GH_xi = np.array(GH['xi'])#Load in the Gauss-Hermite points
    GH_alpha = np.array(GH['alpha'])#Load in the Gauss-Hermite weigths
    M = np.size(X,0)
    m = np.log2(M)
    Dmat = np.zeros((M,M,2))
    Dmat[:,:,0] = np.expand_dims(X[:,0],1) - np.expand_dims(X[:,0],1).T #Calculate the distances between constellation points
    Dmat[:,:,1] = np.expand_dims(X[:,1],1) - np.expand_dims(X[:,1],1).T
    Es = (X[:,0]**2 + X[:,1]**2).mean() #Calculate the signal energy
    EsN0lin = 10**(EsNo_dB/10)  #Turn the SNR value from dB to a linear value
    SigmaZ2 = (Es/(EsN0lin)) #Calculate the noise variance
    sum_0 = 0 #Initialize the sum 

    for l1 in range(10): #Dimension 1
        for l2 in range(10): #Dimension 2
             num = np.exp(-((Dmat[:,:,0]**2 + Dmat[:,:,1]**2) + 2*np.sqrt(SigmaZ2)*(GH_xi[l1]*Dmat[:,:,0] - GH_xi[l2]*Dmat[:,:,1]))/SigmaZ2)
             sum_0 = GH_alpha[l1]*GH_alpha[l2]*np.log(np.sum(num,1))/np.log(2)  + sum_0
    sum_0 = np.sum(sum_0)
    MI = m-1/M/math.pi*sum_0
    return MI

def MI_OW_4D(X_tilde):
    Weights = Weight_Rotation_Random(Weights_base,2)
    X = encoder(X_tilde)
    nf = normalization(X)
    X = X/nf
    Dmat = tr.zeros(M,M,channel_uses).to(Device)
    Dmat[:,:,0] = X[:,0].unsqueeze(1) -(X[:,0].unsqueeze(1)).t() #Calculate the distances between constellation points
    Dmat[:,:,1] = X[:,1].unsqueeze(1) -(X[:,1].unsqueeze(1)).t()
    Dmat[:,:,2] = X[:,2].unsqueeze(1) -(X[:,2].unsqueeze(1)).t()
    Dmat[:,:,3] = X[:,3].unsqueeze(1) -(X[:,3].unsqueeze(1)).t()
    Dmatnorm = Dmat[:,:,0]**2 + Dmat[:,:,1]**2+ Dmat[:,:,2]**2 + Dmat[:,:,3]**2
    Es = (X[:,0]**2 + X[:,1]**2 + X[:,2]**2 + X[:,3]**2).mean() #Calculate the signal energy
    EsN0lin = 10**(EsNo_dB/10)  #Turn the SNR value from dB to a linear value
    SigmaZ2 = (Es/(EsN0lin)) #Calculate the noise variance
    for l1 in range(Weights.size(0)): #Dimension 1
        num = tr.exp(-(Dmatnorm + np.sqrt(2)*tr.sqrt(SigmaZ2)*(Weights[l1,0]*Dmat[:,:,0] - Weights[l1,1]*Dmat[:,:,1] + Weights[l1,2]*Dmat[:,:,2] - Weights[l1,3]*Dmat[:,:,3]))/(0.5*SigmaZ2))
        sum_0= tr.sum(tr.abs(Weights[l1,4])*tr.log(tr.sum(num,0))/tr.log(tr.tensor(2, dtype = tr.float32)))
        sum_0.backward(retain_graph = True)
    return sum_0       

def MI_OW_8D(X_tilde):
    Weights = Weight_Rotation_Random(Weights_base,2)
    X = encoder(X_eye)
    nf = normalization(X)
    X = X/nf
    X2 = encoder(X_tilde)/nf
    Dmat = tr.zeros(M,batch_size,channel_uses).to(Device)
    Dmat[:,:,0] = X[:,0].unsqueeze(1) -(X2[:,0].unsqueeze(1)).t() #Calculate the distances between constellation points
    Dmat[:,:,1] = X[:,1].unsqueeze(1) -(X2[:,1].unsqueeze(1)).t()
    Dmat[:,:,2] = X[:,2].unsqueeze(1) -(X2[:,2].unsqueeze(1)).t()
    Dmat[:,:,3] = X[:,3].unsqueeze(1) -(X2[:,3].unsqueeze(1)).t()
    Dmat[:,:,4] = X[:,4].unsqueeze(1) -(X2[:,4].unsqueeze(1)).t() #Calculate the distances between constellation points
    Dmat[:,:,5] = X[:,5].unsqueeze(1) -(X2[:,5].unsqueeze(1)).t()
    Dmat[:,:,6] = X[:,6].unsqueeze(1) -(X2[:,6].unsqueeze(1)).t()
    Dmat[:,:,7] = X[:,7].unsqueeze(1) -(X2[:,7].unsqueeze(1)).t()
    Dmatnorm = Dmat[:,:,0]**2 + Dmat[:,:,1]**2+ Dmat[:,:,2]**2 + Dmat[:,:,3]**2 + Dmat[:,:,4]**2 + Dmat[:,:,5]**2+ Dmat[:,:,6]**2 + Dmat[:,:,7]**2
    Es = (X[:,0]**2 + X[:,1]**2 + X[:,2]**2 + X[:,3]**2 + X[:,4]**2 + X[:,5]**2 + X[:,6]**2 + X[:,7]**2).mean() #Calculate the signal energy
    EsN0lin = 10**(EsNo_dB/10)  #Turn the SNR value from dB to a linear value
    SigmaZ2 = (Es/(EsN0lin)) #Calculate the noise variance
    sum_0 = 0 #Initialize the sum 
    for l1 in range(Weights.size(0)): #Dimension 1
        num = tr.exp(-(Dmatnorm + 2/np.sqrt(4)*tr.sqrt(SigmaZ2)*(Weights[l1,0]*Dmat[:,:,0] - Weights[l1,1]*Dmat[:,:,1] + Weights[l1,2]*Dmat[:,:,2] - Weights[l1,3]*Dmat[:,:,3] + Weights[l1,4]*Dmat[:,:,4] - Weights[l1,5]*Dmat[:,:,5] + Weights[l1,6]*Dmat[:,:,6] - Weights[l1,7]*Dmat[:,:,7]))/(0.25*SigmaZ2))
        sum_0= tr.sum(tr.abs(Weights[l1,8])*tr.log(tr.sum(num,0))/tr.log(tr.tensor(2, dtype = tr.float32))) + sum_0
    return sum_0      

def MI_OW_12D(X_tilde):
    Weights = Weight_Rotation_Random(Weights_base,2)
    X = encoder(X_tilde)
    nf = normalization(X)
    X = X/nf
    Dmat = tr.zeros(M,batch_size,channel_uses).to(Device)
    Dmat[:,:,0] = X[:,0].unsqueeze(1) -(X[:,0].unsqueeze(1)).t() #Calculate the distances between constellation points
    Dmat[:,:,1] = X[:,1].unsqueeze(1) -(X[:,1].unsqueeze(1)).t()
    Dmat[:,:,2] = X[:,2].unsqueeze(1) -(X[:,2].unsqueeze(1)).t()
    Dmat[:,:,3] = X[:,3].unsqueeze(1) -(X[:,3].unsqueeze(1)).t()
    Dmat[:,:,4] = X[:,4].unsqueeze(1) -(X[:,4].unsqueeze(1)).t() #Calculate the distances between constellation points
    Dmat[:,:,5] = X[:,5].unsqueeze(1) -(X[:,5].unsqueeze(1)).t()
    Dmat[:,:,6] = X[:,6].unsqueeze(1) -(X[:,6].unsqueeze(1)).t()
    Dmat[:,:,7] = X[:,7].unsqueeze(1) -(X[:,7].unsqueeze(1)).t()
    Dmat[:,:,8] = X[:,8].unsqueeze(1) -(X[:,8].unsqueeze(1)).t() #Calculate the distances between constellation points
    Dmat[:,:,9] = X[:,9].unsqueeze(1) -(X[:,9].unsqueeze(1)).t()
    Dmat[:,:,10] = X[:,10].unsqueeze(1) -(X[:,10].unsqueeze(1)).t()
    Dmat[:,:,11] = X[:,11].unsqueeze(1) -(X[:,11].unsqueeze(1)).t()
    Dmatnorm = Dmat[:,:,0]**2 + Dmat[:,:,1]**2+ Dmat[:,:,2]**2 + Dmat[:,:,3]**2 + Dmat[:,:,4]**2 + Dmat[:,:,5]**2+ Dmat[:,:,6]**2 + Dmat[:,:,7]**2 + Dmat[:,:,8]**2 + Dmat[:,:,9]**2+ Dmat[:,:,10]**2 + Dmat[:,:,11]**2
    Es = (X[:,0]**2 + X[:,1]**2 + X[:,2]**2 + X[:,3]**2 + X[:,4]**2 + X[:,5]**2 + X[:,6]**2 + X[:,7]**2 + X[:,8]**2 + X[:,9]**2 + X[:,10]**2 + X[:,11]**2).mean() #Calculate the signal energy
    EsN0lin = 10**(EsNo_dB/10)  #Turn the SNR value from dB to a linear value
    SigmaZ2 = (Es/(EsN0lin)) #Calculate the noise variance
    for l1 in range(Weights.size(0)): #Dimension 1
        num = tr.exp(-(Dmatnorm + 2/np.sqrt(6)*tr.sqrt(SigmaZ2)*(Weights[l1,0]*Dmat[:,:,0] - Weights[l1,1]*Dmat[:,:,1] + Weights[l1,2]*Dmat[:,:,2] - Weights[l1,3]*Dmat[:,:,3] + Weights[l1,4]*Dmat[:,:,4] - Weights[l1,5]*Dmat[:,:,5] + Weights[l1,6]*Dmat[:,:,6] - Weights[l1,7]*Dmat[:,:,7] + Weights[l1,8]*Dmat[:,:,8] - Weights[l1,9]*Dmat[:,:,9] + Weights[l1,10]*Dmat[:,:,10] - Weights[l1,11]*Dmat[:,:,11]))/(SigmaZ2/6))
        sum_0= tr.sum(tr.abs(Weights[l1,12])*tr.log(tr.sum(num,0))/tr.log(tr.tensor(2, dtype = tr.float32)))
        sum_0.backward(retain_graph = True)    

def MI_GH_4D_Numpy(X_tilde,EsNo_dB):
    X = normalization_np(X_tilde,4) 
    GH_xi = np.array(GH['xi'])#Load in the Gauss-Hermite points
    GH_alpha = np.array(GH['alpha'])#Load in the Gauss-Hermite weigths
    M = np.size(X,0)
    m = np.log2(M)
    
    Dmat = np.zeros((M,M,4))
    Dmat[:,:,0] = np.expand_dims(X[:,0],1) - np.expand_dims(X[:,0],1).T #Calculate the distances between constellation points
    Dmat[:,:,1] = np.expand_dims(X[:,1],1) - np.expand_dims(X[:,1],1).T
    Dmat[:,:,2] = np.expand_dims(X[:,2],1) - np.expand_dims(X[:,2],1).T #Calculate the distances between constellation points
    Dmat[:,:,3] = np.expand_dims(X[:,3],1) - np.expand_dims(X[:,3],1).T
    Dmatnorm = Dmat[:,:,0]**2 + Dmat[:,:,1]**2+ Dmat[:,:,2]**2 + Dmat[:,:,3]**2
    Es = (X[:,0]**2 + X[:,1]**2 + X[:,2]**2 + X[:,3]**2).mean() #Calculate the signal energy
    EsN0lin = 10**(EsNo_dB/10)  #Turn the SNR value from dB to a linear value
    SigmaZ2 = (Es/(EsN0lin)) #Calculate the noise variance
    sum_0 = 0 #Initialize the sum 
    for l1 in range(10): #Dimension 1
        for l2 in range(10): #Dimension 2
            for l3 in range(10):
                for l4 in range(10):
                     num = np.exp(-(Dmatnorm + np.sqrt(2)*np.sqrt(SigmaZ2)*(GH_xi[l1]*Dmat[:,:,0] - GH_xi[l2]*Dmat[:,:,1] + GH_xi[l3]*Dmat[:,:,2] - GH_xi[l4]*Dmat[:,:,3]))/(0.5*SigmaZ2))
                     sum_0 = GH_alpha[l1]*GH_alpha[l2]*GH_alpha[l3]*GH_alpha[l4]*np.log(np.sum(num,1))/np.log(tr.tensor(2, dtype = tr.float32))  + sum_0
    sum_0 = tr.sum(sum_0)
    MI = m-1/M/(math.pi**2)*sum_0
    return MI

def MI_OW_4D_Numpy2(X_tilde,EsNo_dB, Weights):
    X = normalization_np(X_tilde,4) 
    M = np.size(X,0)
    m = np.log2(M)
    
    Dmat = np.zeros((M,M,4))
    Dmat[:,:,0] = np.expand_dims(X[:,0],1) - np.expand_dims(X[:,0],1).T #Calculate the distances between constellation points
    Dmat[:,:,1] = np.expand_dims(X[:,1],1) - np.expand_dims(X[:,1],1).T
    Dmat[:,:,2] = np.expand_dims(X[:,2],1) - np.expand_dims(X[:,2],1).T #Calculate the distances between constellation points
    Dmat[:,:,3] = np.expand_dims(X[:,3],1) - np.expand_dims(X[:,3],1).T
    Dmatnorm = Dmat[:,:,0]**2 + Dmat[:,:,1]**2+ Dmat[:,:,2]**2 + Dmat[:,:,3]**2
    Es = (X[:,0]**2 + X[:,1]**2 + X[:,2]**2 + X[:,3]**2).mean() #Calculate the signal energy
    EsN0lin = 10**(EsNo_dB/10)  #Turn the SNR value from dB to a linear value
    SigmaZ2 = (Es/(EsN0lin)) #Calculate the noise variance
    sum_0 = 0 #Initialize the sum 
    for l1 in range(np.size(Weights,0)): #Dimension 1
        num = np.exp(-(Dmatnorm + np.sqrt(2)*np.sqrt(SigmaZ2)*(Weights[l1,0]*Dmat[:,:,0] - Weights[l1,1]*Dmat[:,:,1] + Weights[l1,2]*Dmat[:,:,2] - Weights[l1,3]*Dmat[:,:,3]))/(0.5*SigmaZ2))
        sum_0 = np.abs(Weights[l1,4])*np.log(np.sum(num,1))/np.log(tr.tensor(2, dtype = tr.float32))  + sum_0
    sum_0 = tr.sum(sum_0)
    MI = m-1/M/(math.pi**2)*sum_0
    return MI
#%%The input parameters of the optimization

M =4096#The cardinality size of the constellation
m = np.log2(M) #The amount of bits per symbol
batch_size = 4096
batches = int(M/batch_size)
channel_uses = 12 #The dimensionality of the constellation
Weight_Amount = 512
learning_rate = 0.01 #Learning Rate
EsNo_dB = 6 # The SNR
epochs = 100 #The amount of iterations
Estimation_type = 'OW' #GH or OW
Device = 'cuda' #Determines the device which the optimization is done on, 'cpu' for cpu and 'cuda:0', 'cuda:1' etc. for GPU
# Weights_np = np.load('Weight4.npy',allow_pickle = True)
Weights_np = Weight_initialization(Weight_Amount, channel_uses)
Weights_base = tr.from_numpy(Weights_np)
EsNo_r = 10**(EsNo_dB/10)
sigma2 = 1/(channel_uses*EsNo_r) # noise variance per channel use
GH =  sio.loadmat('GaussHermite_J_10.mat')#Loading in the Gauss-Hermite points
X_eye = tr.eye(M).to(Device) # The input to our neural network
        
#%%Training the model 4D
start_time = time.time()
encoder = tr.nn.Sequential()
encoder.add_module('last', tr.nn.Linear(M,channel_uses,bias = False))
encoder.to(Device)
optimizer = tr.optim.Adam(encoder.parameters(), learning_rate)
loss_history = np.zeros(epochs) # For saving the losses

Constellations = np.zeros((M,channel_uses,epochs)) #For saving the constellations
for i in range(1, epochs+1):
    optimizer.zero_grad()
    for j in range(batches):
        sum_0 = MI_OW_4D(X_eye[np.arange(j*batch_size,(j+1)*batch_size),:])/batches
        sum_0.backward()
    Constellations[:,:,i-1] = encoder(X_eye).cpu().data.numpy()
    optimizer.step()
    if i%100 == 0 or i == 1:
        print('iter ', i, 'time', time.time()- start_time)
    save()
#%% Training the model 8D
start_time = time.time()
encoder = tr.nn.Sequential()
encoder.add_module('last', tr.nn.Linear(M,channel_uses,bias = False))
encoder.to(Device)
optimizer = tr.optim.Adam(encoder.parameters(), learning_rate)
loss_history = np.zeros(epochs) # For saving the losses

Constellations = np.zeros((M,channel_uses,epochs)) #For saving the constellations
for i in range(1, epochs+1):
    optimizer.zero_grad()
    for j in range(batches):
        sum_0 = MI_OW_8D(X_eye[np.arange(j*batch_size,(j+1)*batch_size),:])/batches
        sum_0.backward()
    Constellations[:,:,i-1] = encoder(X_eye).cpu().data.numpy()
    optimizer.step()
    if i%100 == 0 or i == 1:
        print('iter ', i, 'time', time.time()- start_time)
        save()
        
#%% Training the model 12D
start_time = time.time()
encoder = tr.nn.Sequential()
encoder.add_module('last', tr.nn.Linear(M,channel_uses,bias = False))
encoder.to(Device)
optimizer = tr.optim.Adam(encoder.parameters(), learning_rate)

Constellations = np.zeros((M,channel_uses,epochs)) #For saving the constellations
for i in range(1, epochs+1):
    optimizer.zero_grad()
    MI_OW_12D(X_eye)
    Constellations[:,:,i-1] = encoder(X_eye).cpu().data.numpy()
    optimizer.step()
    if i%100 == 0 or i == 1:
        print('iter ', i, 'time', time.time()- start_time)
        save()
#%% Debugging
X = cp.asarray(hf.Generate_ND_PAM(8,4))
MI_MC_Cupy(X,5,5*10**1)