#%%Importing the required packages
import torch as tr
import numpy as np
import matplotlib.pyplot as plt
import scipy.io as sio
import math
import time
import sys
from matplotlib import animation, rc
from IPython.display import HTML
import Functions.Helper_Functions as hf
import gc
#%%Defining some of the functions used
def normalization(x): # E[|x|^2] = 1
    return x / tr.sqrt((channel_uses*(x**2)).mean())
def normalization_np(x,D):
    return x / np.sqrt((D*(x**2)).mean())
def save():
        np.save('./Data/MI/' + str(channel_uses) + 'D/' + str(M) + '/MI_' + Estimation_type + '_' + str(channel_uses) + 'D_' + str(M) + '_' + str(EsNo_dB) + 'dB_'+ str(learning_rate)+'lr', [
          Constellations,
          EsNo_dB,
          epochs,
          learning_rate,
          Device,
          time.time()-start_time], allow_pickle=True)

def Weight_Rotation_Random(Weights,M):
    M = int(M)
    m = int(np.log2(M))
    D_complex = int((Weights.size(1)-1)/2)
    W = tr.zeros(Weights.size(0),Weights.size(1),m).to(Device)
    angles = tr.pi/2*tr.rand(m,D_complex)
    for i in range(m):
        for j in range(D_complex):
            W[:,2*j,i] = Weights[:,2*j] * tr.cos(angles[i,j]) - Weights[:,2*j+1] * tr.sin(angles[i,j])
            W[:,2*j+1,i] = Weights[:,2*j+1] * tr.cos(angles[i,j]) + Weights[:,2*j] * tr.sin(angles[i,j])
        W[:,-1,i] = Weights[:,-1]
    return W

#%% Build the computation graph
def MI_GH(X_tilde):
    X = normalization(encoder(X_tilde)) 
    GH_xi = tr.tensor(GH['xi'], dtype  = tr.float32).to(Device)#Load in the Gauss-Hermite points
    GH_alpha = tr.tensor(GH['alpha'], dtype = tr.float32).to(Device)#Load in the Gauss-Hermite weigths
    
    Dmat = tr.zeros(M,M,channel_uses).to(Device)
    Dmat[:,:,0] = X[:,0].unsqueeze(1) -(X[:,0].unsqueeze(1)).t() #Calculate the distances between constellation points
    Dmat[:,:,1] = X[:,1].unsqueeze(1) -(X[:,1].unsqueeze(1)).t()
    Es = (X[:,0]**2 + X[:,1]**2).mean() #Calculate the signal energy
    MI = 0
    for i in range(np.size(EsNo_dB)):
        EsN0lin = 10**(EsNo_dB[i]/10)  #Turn the SNR value from dB to a linear value
        SigmaZ2 = (Es/(EsN0lin)) #Calculate the noise variance
        sum_0 = 0 #Initialize the sum 
    
        for l1 in range(10): #Dimension 1
            for l2 in range(10): #Dimension 2
                 num = tr.exp(-((Dmat[:,:,0]**2 + Dmat[:,:,1]**2) + 2*tr.sqrt(SigmaZ2)*(GH_xi[l1]*Dmat[:,:,0] - GH_xi[l2]*Dmat[:,:,1]))/SigmaZ2)
                 sum_0 = GH_alpha[l1]*GH_alpha[l2]*tr.log(tr.sum(num,1))/tr.log(tr.tensor(2, dtype = tr.float32))  + sum_0
        sum_0 = tr.sum(sum_0)
        MI = MI +  (m-1/M/math.pi*sum_0)*weight[i]
    loss = -MI
    return loss

def MI_OW(X_tilde):
    X = normalization(encoder(X_tilde)) 
    # Weights = Weight_Rotation_Random(Weights_base, 2).to(Device)
    Weights= Weights_base
    Dmat = tr.zeros(M,M,channel_uses).to(Device)
    Dmat[:,:,0] = X[:,0].unsqueeze(1) -(X[:,0].unsqueeze(1)).t() #Calculate the distances between constellation points
    Dmat[:,:,1] = X[:,1].unsqueeze(1) -(X[:,1].unsqueeze(1)).t()
    Es = (X[:,0]**2 + X[:,1]**2).mean() #Calculate the signal energy
    MI = 0
    for i in range(np.size(EsNo_dB)):
        EsN0lin = 10**(EsNo_dB[i]/10)  #Turn the SNR value from dB to a linear value
        SigmaZ2 = (Es/(EsN0lin)) #Calculate the noise variance
        sum_0 = 0 #Initialize the sum 
        for j in range(Weights.size(0)): #Dimension 1
            num = tr.exp(-((Dmat[:,:,0]**2 + Dmat[:,:,1]**2) + 2*tr.sqrt(SigmaZ2)*(Weights[i,0]*Dmat[:,:,0] - Weights[i,1]*Dmat[:,:,1]))/SigmaZ2)
            sum_0 = tr.abs(Weights[i,2])*tr.log(tr.sum(num,1))/tr.log(tr.tensor(2, dtype = tr.float32))  + sum_0
        sum_0 = tr.sum(sum_0)
        MI = MI +  (m-1/M/math.pi*sum_0)*weight[i]
    loss = -MI
    return loss

def MI_OW_4D(X_tilde):
    X = normalization(encoder(X_tilde)) 
    Dmat = tr.zeros(M,M,channel_uses).to(Device)
    Dmat[:,:,0] = X[:,0].unsqueeze(1) -(X[:,0].unsqueeze(1)).t() #Calculate the distances between constellation points
    Dmat[:,:,1] = X[:,1].unsqueeze(1) -(X[:,1].unsqueeze(1)).t()
    Dmat[:,:,2] = X[:,2].unsqueeze(1) -(X[:,2].unsqueeze(1)).t()
    Dmat[:,:,3] = X[:,3].unsqueeze(1) -(X[:,3].unsqueeze(1)).t()
    Dmatnorm = Dmat[:,:,0]**2 + Dmat[:,:,1]**2+ Dmat[:,:,2]**2 + Dmat[:,:,3]**2
    Es = (X[:,0]**2 + X[:,1]**2 + X[:,2]**2 + X[:,3]**2).mean() #Calculate the signal energy
    EsN0lin = 10**(EsNo_dB[0]/10)  #Turn the SNR value from dB to a linear value
    SigmaZ2 = (Es/(EsN0lin)) #Calculate the noise variance
    sum_0 = 0 #Initialize the sum 
    for l1 in range(Weights.size(0)): #Dimension 1
        for l2 in range(Weights.size(0)): #Dimension 2
                num = tr.exp(-(Dmatnorm + np.sqrt(2)*tr.sqrt(SigmaZ2)*(Weights[l1,0]*Dmat[:,:,0] - Weights[l1,1]*Dmat[:,:,1] + Weights[l2,0]*Dmat[:,:,2] - Weights[l2,1]*Dmat[:,:,3]))/(0.5*SigmaZ2))
                sum_0= tr.sum(tr.abs(Weights[l1,2]*Weights[l2,2])*tr.log(tr.sum(num,1))/tr.log(tr.tensor(2, dtype = tr.float32))) + sum_0
    MI = m-1/M/(math.pi**2)*sum_0
    loss = -MI
    return loss

def MI_OW_4D_test(X_tilde,i):
    X = normalization(encoder(X_tilde)) 
    X_tilde2 = tr.zeros(M).to(Device)
    X_tilde2[i] = 1
    X2 = normalization(encoder(X_tilde2))
    Dmat = tr.zeros(M,channel_uses).to(Device)
    Dmat[:,0] = X[:,0] -X2[0] #Calculate the distances between constellation points
    Dmat[:,1] = X[:,1] -X2[1]
    Dmat[:,2] = X[:,2] -X2[2]
    Dmat[:,3] = X[:,3] -X2[3]
    Dmatnorm = Dmat[:,0]**2 + Dmat[:,1]**2+ Dmat[:,2]**2 + Dmat[:,3]**2
    Es = (X[:,0]**2 + X[:,1]**2 + X[:,2]**2 + X[:,3]**2).mean() #Calculate the signal energy
    EsN0lin = 10**(EsNo_dB[0]/10)  #Turn the SNR value from dB to a linear value
    SigmaZ2 = (Es/(EsN0lin)) #Calculate the noise variance
    sum_0 = 0 #Initialize the sum 
    for l1 in range(Weights.size(0)): #Dimension 1
        for l2 in range(Weights.size(0)): #Dimension 2
                num = tr.exp(-(Dmatnorm + np.sqrt(2)*tr.sqrt(SigmaZ2)*(Weights[l1,0]*Dmat[:,0] - Weights[l1,1]*Dmat[:,1] + Weights[l2,0]*Dmat[:,2] - Weights[l2,1]*Dmat[:,3]))/(0.5*SigmaZ2))
                sum_0 = tr.abs(Weights[l1,2]*Weights[l2,2])*tr.log(tr.sum(num))/tr.log(tr.tensor(2, dtype = tr.float32))  + sum_0
    sum_0 = tr.sum(sum_0)
    return sum_0

def MI_OW_4D2(X_tilde):
    Weights = Weight_Rotation_Random(Weights_base,2)
    X = normalization(encoder(X_tilde)) 
    Dmat = tr.zeros(M,M,channel_uses).to(Device)
    Dmat[:,:,0] = X[:,0].unsqueeze(1) -(X[:,0].unsqueeze(1)).t() #Calculate the distances between constellation points
    Dmat[:,:,1] = X[:,1].unsqueeze(1) -(X[:,1].unsqueeze(1)).t()
    Dmat[:,:,2] = X[:,2].unsqueeze(1) -(X[:,2].unsqueeze(1)).t()
    Dmat[:,:,3] = X[:,3].unsqueeze(1) -(X[:,3].unsqueeze(1)).t()
    Dmatnorm = Dmat[:,:,0]**2 + Dmat[:,:,1]**2+ Dmat[:,:,2]**2 + Dmat[:,:,3]**2
    Es = (X[:,0]**2 + X[:,1]**2 + X[:,2]**2 + X[:,3]**2).mean() #Calculate the signal energy
    EsN0lin = 10**(EsNo_dB[0]/10)  #Turn the SNR value from dB to a linear value
    SigmaZ2 = (Es/(EsN0lin)) #Calculate the noise variance
    sum_0 = 0 #Initialize the sum 
    for l1 in range(Weights.size(0)): #Dimension 1
            num = tr.exp(-(Dmatnorm + np.sqrt(2)*tr.sqrt(SigmaZ2)*(Weights[l1,0]*Dmat[:,:,0] - Weights[l1,1]*Dmat[:,:,1] + Weights[l1,2]*Dmat[:,:,2] - Weights[l1,3]*Dmat[:,:,3]))/(0.5*SigmaZ2))
            sum_0 = tr.abs(Weights[l1,4])*tr.log(tr.sum(num,1))/tr.log(tr.tensor(2, dtype = tr.float32))  + sum_0
    sum_0 = tr.sum(sum_0)
    MI = m-1/M/(math.pi**2)*sum_0
    loss = -MI
    return loss

def MI_OW_8D(X_tilde):
    Weights = Weight_Rotation_Random(Weights_base,2)
    X = normalization(encoder(X_tilde)) 
    Dmat = tr.zeros(M,M,channel_uses).to(Device)
    Dmat[:,:,0] = X[:,0].unsqueeze(1) -(X[:,0].unsqueeze(1)).t() #Calculate the distances between constellation points
    Dmat[:,:,1] = X[:,1].unsqueeze(1) -(X[:,1].unsqueeze(1)).t()
    Dmat[:,:,2] = X[:,2].unsqueeze(1) -(X[:,2].unsqueeze(1)).t()
    Dmat[:,:,3] = X[:,3].unsqueeze(1) -(X[:,3].unsqueeze(1)).t()
    Dmat[:,:,4] = X[:,4].unsqueeze(1) -(X[:,4].unsqueeze(1)).t() #Calculate the distances between constellation points
    Dmat[:,:,5] = X[:,5].unsqueeze(1) -(X[:,5].unsqueeze(1)).t()
    Dmat[:,:,6] = X[:,6].unsqueeze(1) -(X[:,6].unsqueeze(1)).t()
    Dmat[:,:,7] = X[:,7].unsqueeze(1) -(X[:,7].unsqueeze(1)).t()
    Dmatnorm = Dmat[:,:,0]**2 + Dmat[:,:,1]**2+ Dmat[:,:,2]**2 + Dmat[:,:,3]**2 + Dmat[:,:,4]**2 + Dmat[:,:,5]**2+ Dmat[:,:,6]**2 + Dmat[:,:,7]**2
    Es = (X[:,0]**2 + X[:,1]**2 + X[:,2]**2 + X[:,3]**2 + X[:,4]**2 + X[:,5]**2 + X[:,6]**2 + X[:,7]**2).mean() #Calculate the signal energy
    EsN0lin = 10**(EsNo_dB[0]/10)  #Turn the SNR value from dB to a linear value
    SigmaZ2 = (Es/(EsN0lin)) #Calculate the noise variance
    sum_0 = 0 #Initialize the sum 
    for l1 in range(Weights.size(0)): #Dimension 1
        num = tr.exp(-(Dmatnorm + np.sqrt(np.sqrt(2))*tr.sqrt(SigmaZ2)*(Weights[l1,0]*Dmat[:,:,0] - Weights[l1,1]*Dmat[:,:,1] + Weights[l1,2]*Dmat[:,:,2] - Weights[l1,3]*Dmat[:,:,3] + Weights[l1,4]*Dmat[:,:,4] - Weights[l1,5]*Dmat[:,:,5] + Weights[l1,6]*Dmat[:,:,6] - Weights[l1,7]*Dmat[:,:,7]))/(0.25*SigmaZ2))
        sum_0 = tr.sum(tr.abs(Weights[l1,8])*tr.log(tr.sum(num,1))/tr.log(tr.tensor(2, dtype = tr.float32)))  + sum_0
    MI = m-1/M/(math.pi**4)*sum_0
    loss = -MI
    return loss

def MI_GH_MDL(X_tilde):
    GH_xi = tr.tensor(GH['xi'], dtype  = tr.float32).to(Device)#Load in the Gauss-Hermite points
    GH_alpha = tr.tensor(GH['alpha'], dtype = tr.float32).to(Device)#Load in the Gauss-Hermite weigths
    MI = 0
    for i in range(np.size(EsNo_dB)):
        MDL_S = 10**((EsNo_mean[i] - EsNo_dB[i])/10)
        X = encoder(X_tilde)
        X[:,0] = X[:,0]*np.sqrt(MDL_S)
        X = normalization(X)
        Dmat = tr.zeros(M,M,channel_uses).to(Device)
        Dmat[:,:,0] = X[:,0].unsqueeze(1) -(X[:,0].unsqueeze(1)).t() #Calculate the distances between constellation points
        Dmat[:,:,1] = X[:,1].unsqueeze(1) -(X[:,1].unsqueeze(1)).t()
        Es = (X[:,0]**2 + X[:,1]**2).mean() #Calculate the signal energy
        EsN0lin = 10**(EsNo_dB[i]/10)  #Turn the SNR value from dB to a linear value
        SigmaZ2 = (Es/(EsN0lin)) #Calculate the noise variance
        sum_0 = 0 #Initialize the sum 
    
        for l1 in range(10): #Dimension 1
            for l2 in range(10): #Dimension 2
                 num = tr.exp(-((Dmat[:,:,0]**2 + Dmat[:,:,1]**2) + 2*tr.sqrt(SigmaZ2)*(GH_xi[l1]*Dmat[:,:,0] - GH_xi[l2]*Dmat[:,:,1]))/SigmaZ2)
                 sum_0 = GH_alpha[l1]*GH_alpha[l2]*tr.log(tr.sum(num,1))/tr.log(tr.tensor(2, dtype = tr.float32))  + sum_0
        sum_0 = tr.sum(sum_0)
        MI = MI +  (m-1/M/math.pi*sum_0)*weight[i]
    loss = -MI
    return loss

def MI_GH_Numpy(X_tilde,EsNo_dB):
    X = normalization_np(X_tilde,2) 
    GH_xi = np.array(GH['xi'])#Load in the Gauss-Hermite points
    GH_alpha = np.array(GH['alpha'])#Load in the Gauss-Hermite weigths
    M = np.size(X,0)
    m = np.log2(M)
    Dmat = np.zeros((M,M,2))
    Dmat[:,:,0] = np.expand_dims(X[:,0],1) - np.expand_dims(X[:,0],1).T #Calculate the distances between constellation points
    Dmat[:,:,1] = np.expand_dims(X[:,1],1) - np.expand_dims(X[:,1],1).T
    Es = (X[:,0]**2 + X[:,1]**2).mean() #Calculate the signal energy
    EsN0lin = 10**(EsNo_dB/10)  #Turn the SNR value from dB to a linear value
    SigmaZ2 = (Es/(EsN0lin)) #Calculate the noise variance
    sum_0 = 0 #Initialize the sum 

    for l1 in range(10): #Dimension 1
        for l2 in range(10): #Dimension 2
             num = np.exp(-((Dmat[:,:,0]**2 + Dmat[:,:,1]**2) + 2*np.sqrt(SigmaZ2)*(GH_xi[l1]*Dmat[:,:,0] - GH_xi[l2]*Dmat[:,:,1]))/SigmaZ2)
             sum_0 = GH_alpha[l1]*GH_alpha[l2]*np.log(np.sum(num,1))/np.log(2)  + sum_0
    sum_0 = np.sum(sum_0)
    MI = m-1/M/math.pi*sum_0
    return MI

def MI_GH_4D(X_tilde):
    X = normalization(encoder(X_tilde)) 
    GH_xi = tr.tensor(GH['xi'], dtype  = tr.float32).to(Device)#Load in the Gauss-Hermite points
    GH_alpha = tr.tensor(GH['alpha'], dtype = tr.float32).to(Device)#Load in the Gauss-Hermite weigths
    
    Dmat = tr.zeros(M,M,channel_uses).to(Device)
    Dmat[:,:,0] = X[:,0].unsqueeze(1) -(X[:,0].unsqueeze(1)).t() #Calculate the distances between constellation points
    Dmat[:,:,1] = X[:,1].unsqueeze(1) -(X[:,1].unsqueeze(1)).t()
    Dmat[:,:,2] = X[:,2].unsqueeze(1) -(X[:,2].unsqueeze(1)).t()
    Dmat[:,:,3] = X[:,3].unsqueeze(1) -(X[:,3].unsqueeze(1)).t()
    Dmatnorm = Dmat[:,:,0]**2 + Dmat[:,:,1]**2+ Dmat[:,:,2]**2 + Dmat[:,:,3]**2
    Es = (X[:,0]**2 + X[:,1]**2 + X[:,2]**2 + X[:,3]**2).mean() #Calculate the signal energy
    EsN0lin = 10**(EsNo_dB[0]/10)  #Turn the SNR value from dB to a linear value
    SigmaZ2 = (Es/(EsN0lin)) #Calculate the noise variance
    sum_0 = 0 #Initialize the sum 
    for l1 in range(10): #Dimension 1
        for l2 in range(10): #Dimension 2
            for l3 in range(10):
                for l4 in range(10):
                     num = tr.exp(-(Dmatnorm + np.sqrt(2)*tr.sqrt(SigmaZ2)*(GH_xi[l1]*Dmat[:,:,0] - GH_xi[l2]*Dmat[:,:,1] + GH_xi[l3]*Dmat[:,:,2] - GH_xi[l4]*Dmat[:,:,3]))/(0.5*SigmaZ2))
                     sum_0 = GH_alpha[l1]*GH_alpha[l2]*GH_alpha[l3]*GH_alpha[l4]*tr.log(tr.sum(num,1))/tr.log(tr.tensor(2, dtype = tr.float32))  + sum_0
    sum_0 = tr.sum(sum_0)
    MI = m-1/M/(math.pi**2)*sum_0
    loss = -MI
    return loss

def MI_GH_4D_Numpy(X_tilde,EsNo_dB):
    X = normalization_np(X_tilde,4) 
    GH_xi = np.array(GH['xi'])#Load in the Gauss-Hermite points
    GH_alpha = np.array(GH['alpha'])#Load in the Gauss-Hermite weigths
    M = np.size(X,0)
    m = np.log2(M)
    
    Dmat = np.zeros((M,M,4))
    Dmat[:,:,0] = np.expand_dims(X[:,0],1) - np.expand_dims(X[:,0],1).T #Calculate the distances between constellation points
    Dmat[:,:,1] = np.expand_dims(X[:,1],1) - np.expand_dims(X[:,1],1).T
    Dmat[:,:,2] = np.expand_dims(X[:,2],1) - np.expand_dims(X[:,2],1).T #Calculate the distances between constellation points
    Dmat[:,:,3] = np.expand_dims(X[:,3],1) - np.expand_dims(X[:,3],1).T
    Dmatnorm = Dmat[:,:,0]**2 + Dmat[:,:,1]**2+ Dmat[:,:,2]**2 + Dmat[:,:,3]**2
    Es = (X[:,0]**2 + X[:,1]**2 + X[:,2]**2 + X[:,3]**2).mean() #Calculate the signal energy
    EsN0lin = 10**(EsNo_dB/10)  #Turn the SNR value from dB to a linear value
    SigmaZ2 = (Es/(EsN0lin)) #Calculate the noise variance
    sum_0 = 0 #Initialize the sum 
    for l1 in range(10): #Dimension 1
        for l2 in range(10): #Dimension 2
            for l3 in range(10):
                for l4 in range(10):
                     num = np.exp(-(Dmatnorm + np.sqrt(2)*np.sqrt(SigmaZ2)*(GH_xi[l1]*Dmat[:,:,0] - GH_xi[l2]*Dmat[:,:,1] + GH_xi[l3]*Dmat[:,:,2] - GH_xi[l4]*Dmat[:,:,3]))/(0.5*SigmaZ2))
                     sum_0 = GH_alpha[l1]*GH_alpha[l2]*GH_alpha[l3]*GH_alpha[l4]*np.log(np.sum(num,1))/np.log(tr.tensor(2, dtype = tr.float32))  + sum_0
    sum_0 = tr.sum(sum_0)
    MI = m-1/M/(math.pi**2)*sum_0
    return MI

def MI_OW_4D_Numpy(X_tilde,EsNo_dB, Weights):
    X = normalization_np(X_tilde,4) 
    M = np.size(X,0)
    m = np.log2(M)
    
    Dmat = np.zeros((M,M,4))
    Dmat[:,:,0] = np.expand_dims(X[:,0],1) - np.expand_dims(X[:,0],1).T #Calculate the distances between constellation points
    Dmat[:,:,1] = np.expand_dims(X[:,1],1) - np.expand_dims(X[:,1],1).T
    Dmat[:,:,2] = np.expand_dims(X[:,2],1) - np.expand_dims(X[:,2],1).T #Calculate the distances between constellation points
    Dmat[:,:,3] = np.expand_dims(X[:,3],1) - np.expand_dims(X[:,3],1).T
    Dmatnorm = Dmat[:,:,0]**2 + Dmat[:,:,1]**2+ Dmat[:,:,2]**2 + Dmat[:,:,3]**2
    Es = (X[:,0]**2 + X[:,1]**2 + X[:,2]**2 + X[:,3]**2).mean() #Calculate the signal energy
    EsN0lin = 10**(EsNo_dB/10)  #Turn the SNR value from dB to a linear value
    SigmaZ2 = (Es/(EsN0lin)) #Calculate the noise variance
    sum_0 = 0 #Initialize the sum 
    for l1 in range(np.size(Weights,0)): #Dimension 1
        for l2 in range(np.size(Weights,0)): #Dimension 2
            num = np.exp(-(Dmatnorm + 2*np.sqrt(SigmaZ2)*(Weights[l1,0]*Dmat[:,:,0] - Weights[l1,1]*Dmat[:,:,1] + Weights[l2,0]*Dmat[:,:,2] - Weights[l2,1]*Dmat[:,:,3]))/(SigmaZ2))
            sum_0 = np.abs(Weights[l1,2]*Weights[l2,2])*np.log(np.sum(num,1))/np.log(tr.tensor(2, dtype = tr.float32))  + sum_0
    sum_0 = tr.sum(sum_0)
    MI = m-1/M/(math.pi**2)*sum_0
    return MI

def MI_OW_4D_Numpy2(X_tilde,EsNo_dB, Weights):
    X = normalization_np(X_tilde,4) 
    M = np.size(X,0)
    m = np.log2(M)
    
    Dmat = np.zeros((M,M,4))
    Dmat[:,:,0] = np.expand_dims(X[:,0],1) - np.expand_dims(X[:,0],1).T #Calculate the distances between constellation points
    Dmat[:,:,1] = np.expand_dims(X[:,1],1) - np.expand_dims(X[:,1],1).T
    Dmat[:,:,2] = np.expand_dims(X[:,2],1) - np.expand_dims(X[:,2],1).T #Calculate the distances between constellation points
    Dmat[:,:,3] = np.expand_dims(X[:,3],1) - np.expand_dims(X[:,3],1).T
    Dmatnorm = Dmat[:,:,0]**2 + Dmat[:,:,1]**2+ Dmat[:,:,2]**2 + Dmat[:,:,3]**2
    Es = (X[:,0]**2 + X[:,1]**2 + X[:,2]**2 + X[:,3]**2).mean() #Calculate the signal energy
    EsN0lin = 10**(EsNo_dB/10)  #Turn the SNR value from dB to a linear value
    SigmaZ2 = (Es/(EsN0lin)) #Calculate the noise variance
    sum_0 = 0 #Initialize the sum 
    for l1 in range(np.size(Weights,0)): #Dimension 1
        num = np.exp(-(Dmatnorm + np.sqrt(2)*np.sqrt(SigmaZ2)*(Weights[l1,0]*Dmat[:,:,0] - Weights[l1,1]*Dmat[:,:,1] + Weights[l1,2]*Dmat[:,:,2] - Weights[l1,3]*Dmat[:,:,3]))/(0.5*SigmaZ2))
        sum_0 = np.abs(Weights[l1,4])*np.log(np.sum(num,1))/np.log(tr.tensor(2, dtype = tr.float32))  + sum_0
    sum_0 = tr.sum(sum_0)
    MI = m-1/M/(math.pi**2)*sum_0
    return MI

def MI_GH_Xtalk(X_tilde,H_amount):
    X_temp = encoder(X_tilde)
    GH_xi = tr.tensor(GH['xi'], dtype  = tr.float32).to(Device)#Load in the Gauss-Hermite points
    GH_alpha = tr.tensor(GH['alpha'], dtype = tr.float32).to(Device)#Load in the Gauss-Hermite weigths
    MI = 0
    for k in range(H_amount):
        H = tr.from_numpy(np.real(hf.Generate_Transfer_Matrix(channel_uses)))
        H = H.to(tr.float)
        V = tr.from_numpy(hf.Generate_V_Matrix(channel_uses,MDL_S))
        V = V.to(tr.float)
        H = tr.mm(H,V)
        X = normalization(tr.mm(X_temp,H))
        Dmat = tr.zeros(M,M,channel_uses).to(Device)
        Dmat[:,:,0] = X[:,0].unsqueeze(1) -(X[:,0].unsqueeze(1)).t() #Calculate the distances between constellation points
        Dmat[:,:,1] = X[:,1].unsqueeze(1) -(X[:,1].unsqueeze(1)).t()
        Es = (X[:,0]**2 + X[:,1]**2).mean() #Calculate the signal energy
        for i in range(np.size(EsNo_dB)):
            EsN0lin = 10**(EsNo_dB[i]/10)  #Turn the SNR value from dB to a linear value
            SigmaZ2 = (Es/(EsN0lin)) #Calculate the noise variance
            sum_0 = 0 #Initialize the sum 
            for l1 in range(10): #Dimension 1
                for l2 in range(10): #Dimension 2
                     num = tr.exp(-((Dmat[:,:,0]**2 + Dmat[:,:,1]**2) + 2*tr.sqrt(SigmaZ2)*(GH_xi[l1]*Dmat[:,:,0] - GH_xi[l2]*Dmat[:,:,1]))/SigmaZ2)
                     sum_0 = GH_alpha[l1]*GH_alpha[l2]*tr.log(tr.sum(num,1))/tr.log(tr.tensor(2, dtype = tr.float32))  + sum_0
            sum_0 = tr.sum(sum_0)
            MI = MI +  (m-1/M/math.pi*sum_0)
    loss = -MI/H_amount
    return loss
#%%The input parameters of the optimization

M =256#The cardinality size of the constellation
channel_uses = 4 #The dimensionality of the constellation
learning_rate = 0.01 #Learning Rate
EsNo_dB = np.array([9]) # The SNR
weight = np.array([1]) #The probability of each SNR occurring, should sum up to 1 
EsNo_mean = np.array([6])
epochs = 100 #The amount of iterations
Estimation_type = 'OW' #GH or OW
Device = 'cuda' #Determines the device which the optimization is done on, 'cpu' for cpu and 'cuda:0', 'cuda:1' etc. for GPU
H_amount = 1
# Weights_np = np.load('Weight4.npy',allow_pickle = True)
# Data = np.load('Data/GH/4_64_2023-02-08_14-31-40.npy',allow_pickle= True)
# Weights_np = np.column_stack((Data[2],Data[1][:,:,-1]))
Weights_base = tr.from_numpy(Weights_np)
Weights = tr.from_numpy(Weights_np)
MDL_S = 10**(0/10)
m = np.log2(M) #The amount of bits per symbol
EsNo_r = 10**(EsNo_dB/10)
sigma2 = 1/(channel_uses*EsNo_r) # noise variance per channel use
GH =  sio.loadmat('GaussHermite_J_10.mat')#Loading in the Gauss-Hermite points
X_eye = tr.eye(M).to(Device) # The input to our neural network

#%%Training the model
start_time = time.time()
encoder = tr.nn.Sequential()
encoder.add_module('last', tr.nn.Linear(M,channel_uses,bias = False))
encoder.to(Device)
optimizer = tr.optim.Adam(encoder.parameters(), learning_rate)
loss_history = np.zeros(epochs) # For saving the losses

Constellations = np.zeros((M,channel_uses,epochs)) #For saving the constellations
for i in range(1, epochs+1):
    optimizer.zero_grad()
    if Estimation_type == 'GH':
        if channel_uses ==2:
            # loss = MI_GH_Xtalk(X_eye,H_amount)
            loss = MI_GH(X_eye)
        else:
            loss = MI_GH_4D(X_eye)
    else:
        if channel_uses == 2:
            loss = MI_OW(X_eye)
        elif channel_uses == 4:
            loss = MI_OW_4D(X_eye)
            # loss = MI_OW_4D2(X_eye)
        elif channel_uses == 8:
            loss = MI_OW_8D(X_eye)
    loss_history[i-1] = loss
    Constellations[:,:,i-1] = normalization(encoder(X_eye)).cpu().data.numpy()
    loss.backward()
    optimizer.step()
    if i%100 == 0 or i == 1:
        print('iter ', i, ' loss', loss, 'time', time.time()- start_time)
    save()

#%%Plotting the final constellation
Constellation = normalization(encoder(X_eye)).data.cpu().numpy() 
if channel_uses == 4:
    fig = plt.figure()
    ax = fig.add_subplot(131)
    ax.scatter(Constellation[:,0],Constellation[:,1], marker = '.')
    ax.set_aspect(1)
    ax2 = fig.add_subplot(132)
    ax2.scatter(Constellation[:,2],Constellation[:,3], marker = '.')
    ax2.set_aspect(1)
    ax3 = fig.add_subplot(133)
    ax3.plot(loss_history)
else:
    fig = plt.figure()
    ax = fig.add_subplot(121)
    ax.scatter(Constellation[:,0],Constellation[:,1], marker = '.')
    ax.set_aspect(1)
    ax2 = fig.add_subplot(122)
    ax2.plot(loss_history)

#%%Creating an animation of the evolution of the constellation, only works for 2D constellations
plt.rcParams['animation.embed_limit'] = 2**128
def init():
    line[0].set_data([],[])
    line[1].set_data([],[])
    return(line,)

def animate(i):
    x = Constellations[:,0,i]
    y = Constellations[:,1,i]
    line[0].set_data(x,y)
    line[1].set_data(np.linspace(0,i,i),loss_history[0:i])
    return(line,)


fig = plt.figure()
ax = fig.add_subplot(1,2,1)
ax2 = fig.add_subplot(1,2,2)
ax.set_xlim((-1.8,1.8))
ax.set_ylim((-1.8,1.8))
ax2.set_xlim((-1,epochs))
ax2.set_ylim((-max(loss_history)-0.2,-min(loss_history)+0.2))
ax.set_aspect('equal')
ax2.set_xlabel('iterations')
ax2.set_ylabel('loss')
line1, = ax.plot([],[],'.',lw=2,)
line2, = ax2.plot([],[],lw=2,)
line1.set_color('b')
line2.set_color('b')
line = [line1, line2]
anim = animation.FuncAnimation(fig,animate,init_func = init, frames = epochs, interval = 10, blit = False)
anim.save('./Data/MI/' + str(channel_uses) + 'D/' + str(M) + '/MI_' + Estimation_type + '_' + str(channel_uses) + 'D_' + str(M) + '_' + str(EsNo_dB) + 'dB_'+ str(learning_rate)+'lr_animation.mp4') 
HTML(anim.to_jshtml())

#%% Calculating MI for a range of SNR and transfer matrices
H_realizations = 100
MDL_S = 10**(10/10)
sigma_MDL = 2
D = 6
symbols_per_dimension = 2
X = hf.Generate_ND_PAM(2,symbols_per_dimension)
SNR = np.arange(-8,18,0.4)
MI = np.zeros(np.size(SNR))
for k in range(np.size(SNR)):
    for i in range(H_realizations):
        # H = hf.Generate_V_Matrix(D,MDL_S)
        Q = hf.Generate_Q(D)
        eig = hf.get_MDL_CSI(Q,D)
        g = eig*sigma_MDL
        H = np.diag(np.exp(0.5*g))
        H = np.sqrt(D)*H/np.sqrt(np.sum(H**2))
        for j in range(D):
            SNR_temp = SNR[k] + 10*np.log10(H[j,j]**2)
            MI[k] = MI[k] + MI_GH_Numpy(X, SNR_temp)
    MI[k] = MI[k]/(H_realizations)
plt.plot(SNR,MI)
#%% Debug Cell
MI_GH_4D_Numpy(X,6)