import numpy as np
#The modulation function, take as input the bitstream and converts it into the equivalent modulated sequence. 
#The labeling X is always assumed to be ordered starting with binary labeling 0
def Modulation(c,X,D):
    s = int(np.log2(np.size(X,0))/D)
    c_temp = np.zeros((int(np.size(c,0)/s),np.size(c,1)*s))
    for i in range(s):
        c_temp[:,i::s] = c[i::s,:]
    c_dec = np.array(c_temp.dot(1 << np.arange(c_temp.shape[-1] - 1, -1, -1)), dtype = int)
    an = X[c_dec,:]
    return an[:,0::2] + 1j*an[:,1::2]

#A function for generating noise on an AWGN channel
def AWGN_channel(x, SNR, X):
    P = np.mean(np.sum(np.abs(X**2),1))
    EsN0 = (10**(SNR/10))/(P)
    z = np.random.normal(0,1/np.sqrt(EsN0),(np.size(x,0),np.size(x,1))) + 1j*np.random.normal(0,1/np.sqrt(EsN0),(np.size(x,0),np.size(x,1)))
    y = x + z
    return y

def AWGN_channel_general(x,sigmaZ2):
    samples = np.size(x,0)
    channel_uses = np.size(x,1)
    return x + np.sqrt(sigmaZ2)*np.random.normal(size = (samples,channel_uses)) + 1j*np.sqrt(sigmaZ2)*np.random.normal(size = (samples,channel_uses))

def normalization_np(x,D):
    return x / np.sqrt((D*(x**2)).mean())

#Multiplying the channel matrix with the transmitted symbols
def Channel_Matrix(H,x):
    return H.dot(x.T).T

#A function for estimating the received symbols
def Demodulation_BPSK(y):
    y_real = np.zeros((np.size(y,0)*2,np.size(y,1)))
    y_real[0::2,:] = np.real(y)
    y_real[1::2,:] = np.imag(y)
    r = y_real >= 0
    return r*1

def Modulation_general(c,X):
    m = np.log2(np.size(X,0))
    c_dec = bi2de(c, m)
    an = X[c_dec,:]
    return an[:,0::2] + 1j*an[:,1::2]

def Demodulation_general(y,X,x):
    D = int(np.size(y,1))
    Nsym = int(np.size(y,0))
    bps = int(np.log2(np.size(X,0)))
    X_temp = np.expand_dims(X, 2)
    y_real = np.zeros((Nsym,2*D))
    y_real[:,0::2] = np.real(y)
    y_real[:,1::2] = np.imag(y)
    Eucl_dist = np.sum((y_real.T-X_temp)**2,1)
    idx = np.argmin(Eucl_dist,0)
    c = de2bi(idx,bps)
    x_hat = np.zeros((Nsym,D), dtype = np.complex)
    X_temp = X[idx,:]
    for i in range(D):
        x_hat[:,i] = X_temp[:,2*i] + 1j*X_temp[:,2*i+1]
    return c, x_hat

#A function for caluclating the BER of the used modulation
def BER_calc(c,c_hat):
    BER = np.sum(c != c_hat)
    return BER

def SER_calc(x,x_hat):
    return np.sum(x != x_hat)

def de2bi(d, n):
	d = np.array(d)
	power = 2**np.arange(n)
	return (np.floor((d[:,None]%(2*power))/power))

def bi2de(L,m):
    Nsymb = np.size(L,0)
    Ldec = np.zeros(Nsymb, dtype = int)
    for i in range(int(m)):
        Ldec = Ldec + L[:,i]*2**i 
    return Ldec

def MI_calc(x,y,D):
    x = np.round(10**5*x)/10**5
    x_real = np.zeros((np.size(x,0),np.size(x,1)*2))
    y_real = np.zeros((np.size(y,0),np.size(y,1)*2))
    x_real[:,0::2] = np.real(x)
    x_real[:,1::2] = np.imag(x)
    y_real[:,0::2] = np.real(y)
    y_real[:,1::2] = np.imag(y)
    MI = 0
    for i in range(D*2):
        fy = np.histogram(y_real[:,i], bins = 1000, range = (np.amin(y_real[:,i]),np.amax(y_real[:,i])), density = True)[0]
        X_temp = np.unique(x_real[:,i])
        for j in range(np.size(X_temp)):
            y_temp = y_real[x_real[:,i] == X_temp[j],i]
            fx = np.count_nonzero(x_real[:,i] == X_temp[j])/np.size(x_real[:,i])
            fxy = np.histogram(y_temp, bins = 1000, range = (np.amin(y_real[:,i]),np.amax(y_real[:,i])), density = True)[0]
            idx = fxy != 0
            MI = MI+fx*np.sum(fxy[idx]*np.log2(fxy[idx]/(fy[idx])))*(np.amax(y_real[:,i])-np.amin(y_real[:,i]))/1000

    return  MI

def MI_calc_SDM(x,y,D, bins1, bins2, bins3, bins4):
    MI = np.zeros((5,D,D))
    for i in range(D):
        for j in range(D):
            MI[:,i,j] = MI_calc_IQ(x[:,i],y[:,j],bins1,bins2,bins3,bins4)
    return MI
  
def MI_calc_IQ(x,y,bins1,bins2,bins3,bins4):
    x_abs = np.abs(x)
    x_abs = np.round(x_abs*10**5)/10**5
    x_phase = np.angle(x)
    x_phase = np.round(x_phase*10**5)/10**5
    y_abs = np.abs(y)
    y_phase = np.angle(y)
    MI = np.zeros(5)
    #Calculating the amplitude term
    fy = np.histogram(y_abs, bins = 100, range = (np.amin(y_abs),np.amax(y_abs)), density = True)[0]
    x_abs_unique = np.unique(x_abs)
    for i in range(np.size(x_abs_unique)):
        y_temp = y_abs[x_abs == x_abs_unique[i]]
        fx = np.count_nonzero(x_abs == x_abs_unique[i])/np.size(x_abs)
        fxy = np.histogram(y_temp, bins = 100, range = (np.amin(y_abs),np.amax(y_abs)), density = True)[0]
        idx = fxy != 0
        MI[0] = MI[0]+fx*np.sum(fxy[idx]*np.log2(fxy[idx]/(fy[idx])))*(np.amax(y_abs)-np.amin(y_abs))/100
    #Calculating the phase term
    for i in range(np.size(x_abs_unique)):
        x_phase_conditional = x_phase[x_abs == x_abs_unique[i]]
        y_phase_conditional = y_phase[x_abs == x_abs_unique[i]]
        x_phase_unique = np.unique(x_phase_conditional)
        fy_phase_conditional = np.histogram(y_phase_conditional, bins = 100, range = (np.amin(y_phase_conditional),np.amax(y_phase_conditional)), density = True)[0]
        fx_abs = np.count_nonzero(x_abs == x_abs_unique[i])/np.size(x_abs)
        for j in range(np.size(x_phase_unique)):
            y_temp_phase = y_phase_conditional[x_phase_conditional == x_phase_unique[j]]
            fx_phase_conditional = np.count_nonzero(x_phase_conditional == x_phase_unique[j])/np.size(x_phase_conditional)
            fxy_phase_conditional = np.histogram(y_temp_phase, bins = 100,  range = (np.amin(y_phase_conditional),np.amax(y_phase_conditional)), density = True)[0]
            idx = fxy_phase_conditional != 0
            MI[1] = MI[1]+fx_abs*fx_phase_conditional*np.sum(fxy_phase_conditional[idx]*np.log2(fxy_phase_conditional[idx]/(fy_phase_conditional[idx])))*(np.amax(y_phase_conditional)-np.amin(y_phase_conditional))/100
    #Calculating mixed term 1, should equal 0
    fy_abs,fy_abs_bins = np.histogram(y_abs, bins = bins1, range = (np.amin(y_abs),np.amax(y_abs)), density = True)
    for i in range(np.size(fy_abs)-1):
        idx = np.where((y_abs >= fy_abs_bins[i]) & (y_abs <= fy_abs_bins[i+1]))[0]
        if(np.size(idx) > 0):
            x_abs_conditional = x_abs[idx]
            x_abs_unique = np.unique(x_abs_conditional)
            y_phase_conditional = y_phase[idx]
            fy_phase_conditional =  np.histogram(y_phase_conditional, bins = bins2, range = (np.amin(y_phase_conditional),np.amax(y_phase_conditional)), density = True)[0]
            fy_abs_conditional = np.size(idx)/np.size(y_abs)
            for j in range(np.size(x_abs_unique)):
                fx_abs_conditional = np.count_nonzero(x_abs_conditional == x_abs_unique[j])/np.size(x_abs_conditional)
                fxy_phase_conditional = np.histogram(y_phase_conditional[x_abs_conditional == x_abs_unique[j]], bins = bins2,range = (np.amin(y_phase_conditional),np.amax(y_phase_conditional)), density = True)[0]
                idx = fxy_phase_conditional != 0
                MI[2] = MI[2]+fy_abs_conditional*fx_abs_conditional*np.sum(fxy_phase_conditional[idx]*np.log2(fxy_phase_conditional[idx]/(fy_phase_conditional[idx])))*(np.amax(y_phase_conditional)-np.amin(y_phase_conditional))/bins2
    #Calculating mixed term 2
    x_abs_unique = np.unique(x_abs)
    for i in range(np.size(x_abs_unique)):
        fx_abs = np.count_nonzero(x_abs == x_abs_unique[i])/np.size(x_abs)
        y_phase_conditional = y_phase[x_abs == x_abs_unique[i]]
        y_abs_conditional =  y_abs[x_abs == x_abs_unique[i]]
        x_phase_conditional  = x_phase[x_abs == x_abs_unique[i]]
        fy_phase_conditional,fy_phase_bins = np.histogram(y_phase_conditional, bins = bins3, range = (np.amin(y_phase_conditional),np.amax(y_phase_conditional)), density = True)
        for j in range(np.size(fy_phase_conditional)-1):
            idx = np.where((y_phase_conditional >= fy_phase_bins[j]) & (y_phase_conditional <= fy_phase_bins[j+1]))[0]
            if(np.size(idx) > 0):
                x_phase_conditional2 = x_phase_conditional[idx]
                y_abs_conditional2 = y_abs_conditional[idx]
                fy_abs_conditional = np.histogram(y_abs_conditional2, bins = bins4, range = (np.amin(y_abs_conditional2),np.amax(y_abs_conditional2)), density = True)[0]
                x_phase_unique = np.unique(x_phase_conditional2)
                for k in range(np.size(x_phase_unique)):
                    fx_phase_conditional = np.count_nonzero(x_phase_conditional2 == x_phase_unique[k])/np.size(x_phase_conditional2)
                    fxy_abs_conditional = np.histogram(y_abs_conditional2[x_phase_conditional2 == x_phase_unique[k]], bins = bins4, range = (np.amin(y_abs_conditional2),np.amax(y_abs_conditional2)), density = True)[0]
                    idx = fxy_abs_conditional != 0
                    MI[3] = MI[3]+fx_abs*fy_phase_conditional[j]*fx_phase_conditional*np.sum(fxy_abs_conditional[idx]*np.log2(fxy_abs_conditional[idx]/(fy_abs_conditional[idx])))*(np.amax(y_abs_conditional2)-np.amin(y_abs_conditional2))/bins4
    MI[4] = np.sum(MI)
    return MI
    
def Generate_ND_PAM(D,symbols_per_dimension):
    X = np.zeros((D,symbols_per_dimension**D))
    Positions = np.arange(-1*symbols_per_dimension+1,symbols_per_dimension,2)
    for i in range(D):
        idx = 0
        for j in range(symbols_per_dimension**(i+1)):
            X[i,idx:idx+symbols_per_dimension**(D-i-1)] = Positions[np.mod(j,symbols_per_dimension)]
            idx = idx + symbols_per_dimension**(D-i-1)
    return X.T

def Generate_PSK(M):
    X = np.zeros((M,2))
    angles = 2*np.pi*np.arange(M)/M #+ np.pi/M
    X[:,0] = np.sin(angles)
    X[:,1] = np.cos(angles)
    return X

def Moving_Average(fx,w_size):
    return np.convolve(fx,np.ones(w_size), 'valid')/w_size
#A function for calculating the capacity of a multi-mode fibre
#rho_t is the SNR in dB of the channel where the signal power is the total power over all the modes, 
# and the noise power is the noise power per modes
#D are the amount of modes (each polarization is counted as a seperate mode)
def Capacity_MMF(rho_t,D):
    C = D*np.log2(1+rho_t/D)
    return C

def xi_calc(K,sigma_g):
    return np.sqrt(K)*sigma_g

def sigma_MDL_calc(xi):
    return xi*np.sqrt(1+1/12*xi**2)

def chi_calc(rho_t,sigma_MDL,PDF, x, stepsize,D):
    received_power = np.sum(np.exp(sigma_MDL*x)*PDF)*stepsize
    return rho_t/received_power

def Capacity_MMF_MDL(chi,D,x,PDF,sigma_MDL,stepsize):
    return D*np.sum(np.log2(1+(chi/D)*np.exp(sigma_MDL*x))*PDF)*stepsize

#The probability distributions of normalized MDL assuming unit variance
def MDL_dist(x,D):
    if(D == 2):
        return 3*np.sqrt(3/(2*np.pi))*x**2*np.exp(-3/2*x**2)
    elif(D == 3):
        return np.sqrt(2/np.pi)*np.exp(-2*x**2)*(6*x**4-3*x**2+5/8)
    elif(D == 4):
        return np.sqrt(10/np.pi)*np.exp(-5/2*x**2)*(500/81*x**6 - 200/27*x**4 + 25/9*x**2 + 5/54)
    elif(D == 5):
        return np.sqrt(3/np.pi)*np.exp(-3*x**2)*(3375/128*x**8 - 3375/64*x**6 + 8775/256*x**4 - 1185/256*x**2 + 903/2048)
    elif(D == 6):
        return np.sqrt(14/np.pi)*np.exp(-7/2*x**2)*(453789/15625*x**10 - 259308/3125*x**8 + 256221/3125*x**6 - 17492/625*x**4 + 4557/1250*x**2 + 322/3125)
    elif(D == 7):
        return np.sqrt(np.pi)*np.exp(-4*x**2)(8605184/32805*x**12 - 2151296/2187*x**10 + 326536/243*x**8 - 558404/729*x**6 + 361375/1944*x**4 - 30317/2592*x**2 + 88175/124416)
    elif(D == 8):
        return np.sqrt(2/np.pi)*np.exp(-9/2*x**2)*(13060694016/28824005*x**14 - 8707129344/4117715*x**12 + 3083774976/823543*x**10 - 2517744384/823543*x**8 + 140457888/117649*x**6 - 23059728/117649*x**4 + 1533654/117649*x**2 + 502065/1647086)
    else:
        return np.nan_to_num(1/(2*np.pi)*np.sqrt(4-x**2))*(np.abs(x) <=2)
    
def Generate_Q(D):
    Q =np.column_stack((np.ones(D),np.random.normal(0,1,(D,D-1))))
    for i in range(D):
        if(i > 0):
            temp = 0;
            for j in range(i):
                temp = temp+ proj(Q[:,i],Q[:,j])
            Q[:,i] = Q[:,i] - temp
    return Q[:,1:]

def proj(v,u):
    return (np.inner(u,v)/np.inner(u,u))*u

def get_MDL_CSI(Q,D):
    A = np.random.normal(0,0.5,(D,D)) + np.random.normal(0,0.5,(D,D))*1j
    A = A + A.conj().T
    diag = np.random.normal(0,1,D-1);
    diag = Q.dot(diag)
    var_diag = np.var(diag)
    diag = diag/np.sqrt(var_diag)
    np.fill_diagonal(A,diag)
    eig,eigvec = np.linalg.eigh(A)
    eig = eig/np.sqrt(D)
    return eig

def calc_mu(chi,g,D):
    delta = 50
    mu = 100
    for i in range(100):
        temp = np.sum(np.maximum(0,mu-np.exp(-g)))
        if (temp > chi):
            mu = mu - delta
        else:
            mu = mu + delta
        delta = delta/2
    return mu

def Capacity_MMF_MDL_CSI(mu,g,D):
    return np.sum(np.log2(1+np.maximum(0,mu*np.exp(g)-1)))

def Generate_Transfer_Matrix(D):
    z = (np.random.normal(0,1,(D,D)) + 1j*np.random.normal(0,1,(D,D)))/np.sqrt(2.0)
    q,r = np.linalg.qr(z)
    d = np.diagonal(r)
    ph = d/np.absolute(d)
    ph = np.eye(D)*ph
    q = q.dot(ph)
    return q

def Generate_V_Matrix(D,MDL_S):
    if(D == 1):
        return np.array(1)
    else:
        MDL = np.zeros(D)
        MDL[0] = np.random.uniform(D/(2*MDL_S+3),D/(MDL_S+3))
        MDL[1] = MDL[0]*MDL_S
        temp = np.random.uniform(MDL[0],MDL[1],size = D-2)
        MDL[2:] = temp
        MDL = MDL*D/(np.sum(MDL))
        idx = np.random.permutation(D)
        return np.sqrt(np.eye(D)*MDL[idx])

def Capacity_MMF_MDL_Winzer(labda,E0N0,L):
    return np.sum(np.log2(1+labda*L*E0N0))

def Pout_calc(C,Ct):
    N = np.size(C,0)
    return np.count_nonzero(C < Ct)/N

