#%%Importing all the required packages
import torch as tr
import numpy as np
import matplotlib.pyplot as plt
import scipy.io as sio
import math
import time
import sys
from matplotlib import animation, rc
from IPython.display import HTML
import Functions.Helper_Functions as hf
import cupy as cp
#%%Defining some of the functions used
def awgn_channel(x,sigmaZ2):
    samples = cp.size(x,0)
    channel_uses = cp.size(x,1)
    return x + cp.sqrt(sigmaZ2)*cp.random.normal(size = (samples,channel_uses))

def awgn_channel_np(x,sigmaZ2):
    samples = np.size(x,0)
    channel_uses = np.size(x,1)
    return x + np.sqrt(sigmaZ2)*np.random.normal(size = (samples,channel_uses))

def Weight_initialization(Weight_Amount, channel_uses):
    xi = np.random.normal(0,1,(Weight_Amount,channel_uses))
    alpha = np.exp(-np.sum(xi**2,1)/2)
    return np.column_stack((xi,alpha))

def de2bi(d, n):
	d = np.array(d)
	power = 2**np.arange(n)
	return (np.floor((d[:,None]%(2*power))/power))

def bi2de(L,m):
    Ldec = np.zeros((int(2**m),1), dtype = int)
    for i in range(int(m)):
        for j in range(int(2**m)):
            Ldec[j] = Ldec[j] + L[j,i]*2**i 
    return Ldec
    
def get_labeling(m):
    M  = 2**m
    if m == 1:
        L = np.asarray([[0],[1]])
    else:
        L = np.zeros((M,m))
        L[0:int(M/2),1:m] = get_labeling(m-1)
        L[int(M/2):M, 1:m] = np.flipud(L[0:int(M/2),1:m])
        L[int(M/2):M,0] = 1
    return L

def get_constellation(M):
    Delta = np.sqrt(3/(2*(M-1)))
    Xpam = np.expand_dims(Delta*np.arange(-(np.sqrt(M)-1),np.sqrt(M)+1,2),axis = 1)
    xpamt_2D = np.tile(Xpam,(1,int(np.sqrt(M))))
    xpamt = np.expand_dims(xpamt_2D.flatten(),axis = 1)
    X = np.transpose(np.reshape(np.asarray([xpamt, np.tile(Xpam,(int(np.sqrt(M)),1))]),(2,M)))
    Ltmp = get_labeling(int(np.log2(M)/2))
    Ltmp_dec = bi2de(Ltmp,int(np.log2(M))/2)
    Ltmp_dec2 = np.tile(Ltmp_dec,(1,int(np.sqrt(M))))
    Ltmp_dec3 = np.expand_dims(Ltmp_dec2.flatten(),axis = 1)
    L = np.concatenate((np.reshape(de2bi(Ltmp_dec3,int(np.log2(M)/2)),(M,int(np.log2(M)/2))), np.tile(Ltmp,(int(np.sqrt(M)),1))), axis = 1)
    Ldec = np.reshape(np.asarray(bi2de(np.fliplr(L),int(np.log2(M))),dtype = int),M)
    return [X,Ldec]

def get_APSK(M2,Amount_of_Rings):
    M = int(M2/Amount_of_Rings) * np.ones(Amount_of_Rings, dtype = int)
    X = np.zeros((sum(M),2))
    if Amount_of_Rings > 1:
        idx = 0
        l_r1 = get_labeling(int(np.log2(M[0])))*M.shape[0]
        ldec_r1 = bi2de(l_r1,int(np.log2(M[0])))
        l_rs = get_labeling(int(np.log2(M.shape[0])))
        ldec_rs = bi2de(l_rs,int(np.log2(M.shape[0])))
        l_apsk = np.zeros((sum(M),1),dtype = int)
        for i in range(M.shape[0]):
            R = np.sqrt(-np.log(1-(i+0.5)*1/M.shape[0]))
            for j in range(M[i]):
                X[idx+j,:] = [R*np.cos(j*2*math.pi/M[i]), R*np.sin(j*2*math.pi/M[i]) ]
            l_apsk[idx:idx+M[i],] = ldec_r1 + ldec_rs[i]
            idx = idx + M[i]
        l_apsk = np.squeeze(l_apsk)
    else:
        Lbin = get_labeling(int(np.log2(M[0])))
        l_apsk = np.squeeze(bi2de(Lbin,int(np.log2(M[0]))))
        for j in range(M2):
             X[j,:] = [np.cos(j*2*math.pi/M2), np.sin(j*2*math.pi/M2)]
    return [X, l_apsk]

def get_constellation_4D(M):
    m = int(np.log2(M))
    m_pd = int(m/4)
    Delta = np.sqrt(np.sqrt(3/(2*(M-1))))
    Xpam = np.expand_dims(Delta*np.arange(-(np.sqrt(np.sqrt(M))-1),np.sqrt(np.sqrt(M))+1,2),axis = 1)
    Lpam = get_labeling(m_pd)
    X1 =  (np.expand_dims(np.ones(int(M/2**m_pd)),axis= 1)*np.transpose(Xpam)).flatten('F')
    X2 =  np.tile((np.expand_dims(np.ones(int(M/2**(m_pd*2))),axis= 1)*np.transpose(Xpam)).flatten('F'), 2**m_pd)
    X3 =  np.tile((np.expand_dims(np.ones(int(M/2**(m_pd*3))),axis= 1)*np.transpose(Xpam)).flatten('F'), 2**(m_pd*2))
    X4 =  np.tile((np.expand_dims(np.ones(int(M/2**(m_pd*4))),axis= 1)*np.transpose(Xpam)).flatten('F'), 2**(m_pd*3))
    L1 =  np.reshape(np.tile(Lpam,(int(M/2**m_pd))), (M,m_pd))
    L2 =  np.tile(np.reshape(np.tile(Lpam,(int(M/2**(m_pd*2)))), (int(M/2**m_pd),m_pd)),(2**m_pd,1))
    L3 =  np.tile(np.reshape(np.tile(Lpam,(int(M/2**(m_pd*3)))), (int(M/2**(m_pd*2)),m_pd)),(2**(m_pd*2),1))
    L4 =  np.tile(np.reshape(np.tile(Lpam,(int(M/2**(m_pd*4)))), (int(M/2**(m_pd*3)),m_pd)),(2**(m_pd*3),1))
    X = np.transpose(np.asarray([X1,X2,X3,X4]))
    Lbin =np.asarray(np.concatenate((L1,L2,L3,L4),axis = 1), dtype = int)
    Ldec = np.squeeze(bi2de(Lbin,m))
    return [X,Ldec]  

def get_APSK_8D(M, Amount_of_Rings):
    m = int(np.log2(M))
    M2 = int(np.sqrt(M))
    X_4D, l_apsk_4D = get_APSK_4D(M2,Amount_of_Rings)
    Lbin_4D = de2bi(l_apsk_4D, int(m/2))
    X1 = np.repeat(X_4D,M2,axis = 0)
    X2 = np.reshape(np.repeat(X_4D,M2,axis = 1), (M,4), 'F')
    L1 = np.repeat(Lbin_4D, M2, axis = 0)
    L2 = np.reshape(np.repeat(Lbin_4D,M2,axis = 1), (M,int(m/2)), 'F')
    X = np.concatenate([X1,X2], axis = 1)
    Lbin = np.concatenate([L1,L2], axis = 1)
    Ldec = np.squeeze(bi2de(Lbin,m))
    return[X,Ldec]

def get_APSK_4D(M, Amount_of_Rings):
    m = int(np.log2(M))
    M2 = int(np.sqrt(M))
    X_2D, l_apsk_2D = get_APSK(M2,Amount_of_Rings)
    Lbin_2D = de2bi(l_apsk_2D, int(m/2))
    X1 = np.repeat(X_2D,M2,axis = 0)
    X2 = np.reshape(np.repeat(X_2D,M2,axis = 1), (M,2), 'F')
    L1 = np.repeat(Lbin_2D, M2, axis = 0)
    L2 = np.reshape(np.repeat(Lbin_2D,M2,axis = 1), (M,int(m/2)), 'F')
    X = np.concatenate([X1,X2], axis = 1)
    Lbin = np.concatenate([L1,L2], axis = 1)
    Ldec = np.squeeze(bi2de(Lbin,m))
    return[X,Ldec]

def get_Optimized_4D(X_2D, l_2D, M):
    m = int(np.log2(M)) 
    M2 = int(np.sqrt(M))
    Lbin_2D = de2bi(l_2D, int(m/2))
    X1 = np.repeat(X_2D,M2,axis = 0)
    X2 = np.reshape(np.repeat(X_2D,M2,axis = 1), (M,2), 'F')
    L1 = np.repeat(Lbin_2D, M2, axis = 0)
    L2 = np.reshape(np.repeat(Lbin_2D,M2,axis = 1), (M,int(m/2)), 'F')
    X = np.concatenate([X1,X2], axis = 1)
    Lbin = np.concatenate([L1,L2], axis = 1)
    Ldec = np.squeeze(bi2de(Lbin,m))
    return[X,Ldec]

def get_Random_4D(M):
    m = int(np.log2(M))
    M2 = int(M/16)
    X_G = abs(np.random.normal(0,1,(M2,4)))
    L_2D = get_labeling(m)
    L_Q = get_labeling(4)
    X_T = np.tile(X_G,[16,1])
    Q_M = 2*L_Q -1
    Q_M = np.repeat(Q_M,M2, axis = 0)
    X_RN = X_T*Q_M
    L_2D = np.tile(L_2D,[16,1])
    L_Q = np.repeat(L_Q,M2,axis = 0)
    Lbin = np.concatenate([L_2D,L_Q],axis = 1)
    Ldec = np.squeeze(bi2de(Lbin,m))
    return[X_RN,Ldec]

def get_BPSK_11bits_12D():
    X = hf.Generate_ND_PAM(12, 2)
    X = X[0:2048,:]
    Ldec = np.arange(0,2048)
    return X, Ldec

def normalization(x): # E[|x|^2] = 1
    return x / tr.sqrt((channel_uses*(x**2)).mean())

def normalization_np(x,D):
    return x / np.sqrt((D*(x**2)).mean())

def normalization_cp(x,D):
    return x / cp.sqrt((D*(x**2)).mean())

def save():
        np.save('./Data/GMI/' + str(channel_uses) + 'D/' + str(M) + '/GMI_' + Estimation_type + '_' + str(channel_uses) + 'D_' + str(M) + '_' + str(EsNo_dB) + 'dB_'+ str(learning_rate)+'lr' + Initial_Constellation, [
          Constellations,
          EsNo_dB,
          idx_train,
          epochs,
          learning_rate,
          Device,
          time.time()-start_time], allow_pickle=True)


def Weight_Rotation(Weights,M):
    M = int(M)
    m = int(np.log2(M))
    W = np.zeros((np.size(Weights,0),3,m))
    for i in range(m):
        W[:,0,i] = Weights[:,0] * np.cos(np.pi/2/m*i) - Weights[:,1] * np.sin(np.pi/2/m*i)
        W[:,1,i] = Weights[:,1] * np.cos(np.pi/2/m*i) + Weights[:,0] * np.sin(np.pi/2/m*i)
        W[:,2,i] = Weights[:,2]
    return W

def Weight_Rotation_Random(Weights,M):
    M = int(M)
    m = int(np.log2(M))
    D_complex = int((Weights.size(1)-1)/2)
    W = tr.zeros(Weights.size(0),Weights.size(1),m).to(Device)
    angles = tr.pi/2*tr.rand(m,D_complex)
    for i in range(m):
        for j in range(D_complex):
            W[:,2*j,i] = Weights[:,2*j] * tr.cos(angles[i,j]) - Weights[:,2*j+1] * tr.sin(angles[i,j])
            W[:,2*j+1,i] = Weights[:,2*j+1] * tr.cos(angles[i,j]) + Weights[:,2*j] * tr.sin(angles[i,j])
        W[:,-1,i] = Weights[:,-1]
    return W
#%%=====================================================#
# build the computation graph
#=====================================================#
def GMI_OW(X_tilde,idx):
    Weights = Weight_Rotation_Random(Weights_base, M)
    for i in range(int(channel_uses)):
        if i%2 == 0:
            Weights[:,i,:] = Weights[:,i,:]*-1
    X = encoder(X_tilde)
    X = normalization(X)
    idx2 = np.zeros(M)
    for i in range(M):
        idx2[idx[i]] = i 
    X = X[idx2,:]
    Dmat = tr.zeros(M,M,channel_uses,requires_grad=True).to(Device)
    for i in range(channel_uses):
        Dmat[:,:,i] = X[:,i].unsqueeze(1) -(X[:,i].unsqueeze(1)).t() #Calculate the distances between constellation points
    
    Ik1 = np.zeros([int(M/2),int(m),1]) #Find the pointers to the subconstellations
    Ik0 = np.zeros([int(M/2),int(m),1])
    Ikden1 = np.zeros([int(M/2),int(M/2),int(m)])
    Ikden0 = np.zeros([int(M/2),int(M/2),int(m)])
    for kk in range(int(m)): 
        Ik1[:,kk,0] = np.where(labeling[:,kk] == 1)[0]
        Ik0[:,kk,0] = np.where(labeling[:,kk] == 0)[0]
        Ikden1[:,:,kk] = Ik1[:,kk,:] + M*Ik1[:,kk,:].T + kk*M**2
        Ikden0[:,:,kk] = Ik0[:,kk,:] + M*Ik0[:,kk,:].T + kk*M**2
        Ik1[:,kk,0] = Ik1[:,kk,0]  + kk*M
        Ik0[:,kk,0] = Ik0[:,kk,0]  + kk*M
    Ik1 = tr.tensor(np.squeeze(Ik1), dtype = tr.int64).to(Device)
    Ik0 = tr.tensor(np.squeeze(Ik0), dtype = tr.int64).to(Device)
    Ikden1 = tr.tensor(Ikden1, dtype = tr.int64).to(Device)
    Ikden0 = tr.tensor(Ikden0, dtype = tr.int64).to(Device)
    
    Es = tr.sum(X**2,1).mean() #Calculate the signal energy
    EsN0lin = 10**(EsNo_dB/10)  #Turn the SNR value from dB to a linear value
    SigmaZ2 = (Es/(EsN0lin)) #Calculate the noise 
    
    Dmatnorm = tr.sum(Dmat**2,2).unsqueeze(2)
    Dmat = Dmat.unsqueeze(3).repeat([1, 1, 1,bpg])
    loops = int(m/bpg)
    for l1 in range(Weights.size(0)): #Dimension 1
        for k in range(loops):
            num = tr.exp(-(Dmatnorm + 2/np.sqrt(channel_uses/2)*tr.sqrt(SigmaZ2)*(tr.sum(Weights[l1,0:channel_uses,k*bpg:(k+1)*bpg]*Dmat,2)))/(2*SigmaZ2/channel_uses)).T
            a = num.sum(1)
            num0 = a.take(Ik0[:,k*bpg:(k+1)*bpg])
            den0 = num.take(Ikden0[:,:,k*bpg:(k+1)*bpg]).sum(1)
            den1 = num.take(Ikden1[:,:,k*bpg:(k+1)*bpg]).sum(1)
            num1 = a.take(Ik1[:,k*bpg:(k+1)*bpg])
            sum_0 = tr.sum(tr.abs(Weights[l1,channel_uses,k*bpg:(k+1)*bpg])*tr.log(num0/den0)/tr.log(tr.tensor(2, dtype = tr.float32))) 
            sum_1 = tr.sum(tr.abs(Weights[l1,channel_uses,k*bpg:(k+1)*bpg])*tr.log(num1/den1)/tr.log(tr.tensor(2, dtype = tr.float32)))
            loss = sum_0 + sum_1
            loss.backward(retain_graph=True)
#%% Defining some of the parameters of the optimization
M = 64 #The cardinality size of the constellation
channel_uses = 4 #The dimensionality of the constellation
learning_rate = 0.1 #Learning Rate
EsNo_dB = 6
epochs = 300 #The amount of iterations
bpg = 6#The amount of bits which are being calculated simultaneously per backward propagation
Estimation_type = 'OW' #GH or MC
Device = 'cuda' #Determines the device which the optimization is done on, 'cpu' for cpu and 'cuda:0', 'cuda:1' etc. for GPU
Initial_Constellation = 'APSK' #You can choose either 'APSK', 'QAM', and in the case of 4D 'Random' or the directory to an optimized 2D constellation
Amount_of_Rings =2#Only relevant for APSK, tells you how many rings you want in the constellation, should be a power of 2
Weight_amount = 128
Weights_np = Weight_initialization(Weight_amount,channel_uses)
# Weights_np = np.load('Weight_4D.npy',allow_pickle = True)
Weights_base = tr.from_numpy(Weights_np).to(Device)
m = int(np.log2(M)) #The amount of bits per symbol
EsNo_r = 10**(EsNo_dB/10)
sigma2 = 1/(channel_uses*EsNo_r) # noise variance per channel use
GH =  sio.loadmat('GaussHermite_J_10.mat')#Loading in the Gauss-Hermite points
X_eye = tr.eye(M).to(Device) # The input to our neural network
if channel_uses == 2:
    if Initial_Constellation == 'QAM':
        [X_target,idx_train]= get_constellation(M)
    else:
        [X_target,idx_train] = get_APSK(M,Amount_of_Rings)
        Initial_Constellation = Initial_Constellation + '_' + str(Amount_of_Rings) + 'Rings'
elif channel_uses == 4:
    if Initial_Constellation == 'QAM':
        [X_target,idx_train]= get_constellation_4D(M)
    elif Initial_Constellation == 'APSK':
        [X_target,idx_train] = get_APSK_4D(M,Amount_of_Rings)
        Initial_Constellation = Initial_Constellation + '_' + str(Amount_of_Rings) + 'Rings'
    elif Initial_Constellation == 'Random':
        [X_target,idx_train] = get_Random_4D(M)
    else:
        Optimized_Constellation_2D = tr.load(Initial_Constellation)
        X_2D = Optimized_Constellation_2D['constellations'][:,:,-1]
        l_2D =  Optimized_Constellation_2D['Ldec']
        [X_target,idx_train] = get_Optimized_4D(X_2D,l_2D,M)
        Initial_Constellation = 'Optimized_2D'
elif channel_uses == 8:
    [X_target,idx_train] = get_APSK_8D(M,Amount_of_Rings)
    Initial_Constellation = Initial_Constellation + '_' + str(Amount_of_Rings) + 'Rings'
else:
    [X_target,idx_train] = get_BPSK_11bits_12D()
labeling = de2bi(np.arange(M), m)
# X_target = (-1)**labeling
# idx_train = np.arange(M)
X_target = tr.tensor(X_target,dtype = tr.float32).to(Device)
X_target = normalization(X_target)

#%% Training the model
start_time = time.time()
Constellations = np.zeros((M,channel_uses,epochs)) #For saving the constellations
encoder = tr.nn.Sequential()

encoder.add_module('last', tr.nn.Linear(M,channel_uses,bias = False))
encoder.last.weight = tr.nn.Parameter(X_target.T)
encoder.to(Device)
optimizer = tr.optim.Adam(encoder.parameters(), learning_rate)
for i in range(1, epochs+1):
    optimizer.zero_grad()
    GMI_OW(X_eye, idx_train)
    Constellations[:,:,i-1] = normalization(encoder(X_eye)).detach().cpu().numpy()
    if i%10 == 0 or i ==1:
        print('iter ', i, 'time', time.time()-start_time)
    optimizer.step()
    save()

#%%Plotting the final constellation with labeling
constellation = Constellations[:,:,-1]
x = constellation[:, 0] #Change from 0 to 2 for the second 2D for 4D constellations
y = constellation[:, 1] #Change from 1 to 3 for the second 2D for 4D constellations
max_axis = 1.8
fig = plt.figure(figsize=(m*3-3,3))

for i in range(int(m)):
	ax1 = plt.subplot(1, m, i+1)
	ax1.scatter(x[labeling[:,i] == 0], y[labeling[:,i] == 0], c='b', marker='.')
	ax1.scatter(x[labeling[:,i] == 1], y[labeling[:,i] == 1], c='r', marker='.')
	
	plt.xlabel('X')
	plt.ylabel('Y')
	plt.grid()
	#plt.axis('equal')
	plt.gca().set_aspect('equal', adjustable='box')
	plt.xlim(-max_axis, max_axis)
	plt.ylim(-max_axis, max_axis)
	ax1.set_title('bit position {}'.format(i))

plt.show()
#%% Debugging
def GMI_GH_Numpy(X_tilde,idx, EsNo_dB):
    X = normalization_np(X_tilde,2)
    M = int(np.size(X,0))
    m = int(np.log2(M))
    channel_uses = np.size(X,1)
    idx2 = np.zeros(M, dtype = int)
    labeling = de2bi(np.arange(M), m)
    for i in range(M):
        idx2[idx[i]] = i 
    X = X[idx2,:]
    Dmat = np.zeros((M,M,channel_uses))
    for i in range(channel_uses):
        Dmat[:,:,i] = np.expand_dims(X[:,i],1) - np.expand_dims(X[:,i],1).T #Calculate the distances between constellation points
    
    Ik1 = np.zeros([int(M/2),1,int(m)],dtype = int) #Find the pointers to the subconstellations
    Ik0 = np.zeros([int(M/2),1,int(m)],dtype = int)
    for kk in range(int(m)): 
        Ik1[:,0,kk] = np.where(labeling[:,kk] == 1)[0]
        Ik0[:,0,kk] = np.where(labeling[:,kk] == 0)[0]
    Ikden1 = Ik1 + M*np.transpose(Ik1,(1,0,2))
    Ikden0 = Ik0 + M*np.transpose(Ik0,(1,0,2))
    
    GH =  sio.loadmat('GaussHermite_J_10.mat')#Loading in the Gauss-Hermite points
    GH_xi = np.array(GH['xi'])#Load in the Gauss-Hermite points
    GH_alpha = np.array(GH['alpha'])#Load in the Gauss-Hermite weigths
    
    xi = np.zeros((10**channel_uses,channel_uses))
    alpha = np.ones(10**channel_uses)
    for i in range(channel_uses):
        for j in range(10**i):
            xi[j*10**(channel_uses-i):(j+1)*10**(channel_uses-i),i] = np.repeat(GH_xi,10**(channel_uses-i-1))
            alpha[j*10**(channel_uses-i):(j+1)*10**(channel_uses-i)] = alpha[j*10**(channel_uses-i):(j+1)*10**(channel_uses-i)]*np.repeat(GH_alpha,10**(channel_uses-i-1))
    Es = np.sum(X**2,1).mean() #Calculate the signal energy
    EsN0lin = 10**(EsNo_dB/10)  #Turn the SNR value from dB to a linear value
    SigmaZ2 = (Es/(EsN0lin)) #Calculate the noise 
    
    sum_0 = np.zeros((int(M/2),m))
    sum_1 = np.zeros((int(M/2),m))
    l_2 = np.log(2)
    GMI = 0
    Dmatnorm = np.sum(Dmat**2,2)
    for l1 in range(10**channel_uses): #Dimension 1
        num = np.exp(-(Dmatnorm + 2*np.sqrt(SigmaZ2)/np.sqrt(channel_uses/2)*(np.sum(xi[l1]*Dmat,2)))/(2*SigmaZ2/channel_uses))
        a = num.sum(1)
        num0 = np.squeeze(a.take(Ik0))
        den0 = np.squeeze(num.take(Ikden0).sum(1))
        den1 = np.squeeze(num.take(Ikden1).sum(1))
        num1 = np.squeeze(a.take(Ik1))
        sum_0 = alpha[l1]*np.log(num0/den0)/l_2 +sum_0
        sum_1 = alpha[l1]*np.log(num1/den1)/l_2 +sum_1
    sum_0 = np.sum(sum_0)
    sum_1 = np.sum(sum_1)
    GMI = m-1/M/(math.pi**(channel_uses/2))*(sum_0 + sum_1)
    return GMI

def GMI_MC_Cupy(X,EsNo_dB,idx,samples):
    M = cp.size(X,0)
    m = np.log2(M)
    channel_uses = cp.size(X,1)
    X = normalization_cp(X,channel_uses)
    idx2 = np.zeros(M,dtype = int)
    for i in range(M):
        idx2[idx[i]] = i 
    X = X[idx2,:]
    labeling =de2bi(np.arange(M),m)
    x_idx = np.random.randint(low = 0, high = M, size = samples)
    labeling2 = de2bi(x_idx, m)
    x = X[x_idx,:]
    sigmaZ2 = 1/(channel_uses*10**(EsNo_dB/10))
    y = awgn_channel(x,sigmaZ2)                
    
    Ik1 = np.zeros([int(M/2),int(m)],dtype = int) #Find the pointers to the subconstellations
    Ik0 = np.zeros([int(M/2),int(m)],dtype = int)
    Ikx0 = np.zeros((samples,int(m)), dtype = bool)
    Ikx1 = np.zeros((samples,int(m)), dtype = bool)
    for kk in range(int(m)): 
        Ik1[:,kk] = np.where(labeling[:,kk] == 1)[0]
        Ik0[:,kk] = np.where(labeling[:,kk] == 0)[0]
        Ikx0[np.where(labeling2[:,kk] == 0)[0],kk] = True
        Ikx1[np.where(labeling2[:,kk] == 1)[0],kk] = True
    # compute posterior distribution
    xx = cp.repeat(cp.expand_dims(X,1),samples,1)
    yy = cp.repeat(cp.expand_dims(y,0),M,0)
    
    MI = 0
    for i in range(int(m)):
        num0 = cp.exp(-cp.sum((y[Ikx0[:,i]]-x[Ikx0[:,i]])**2,1)/(2*sigmaZ2)) # f_{Y|X}
        den0 = cp.exp(-cp.sum((yy[:,Ikx0[:,i]]-xx[:,Ikx0[:,i]])**2,2)/(2*sigmaZ2)).mean(0) # f_{Y}
        posterior0 = num0/den0
        num1 = cp.exp(-cp.sum((y[Ikx1[:,i]]-x[Ikx1[:,i]])**2,1)/(2*sigmaZ2)) # f_{Y|X}
        den1 = cp.exp(-cp.sum((yy[:,Ikx1[:,i]]-xx[:,Ikx1[:,i]])**2,2)/(2*sigmaZ2)).mean(0) # f_{Y}
        posterior1 = num1/den1
        MI = (cp.sum(cp.log2(posterior0)) + cp.sum(cp.log2(posterior1)))/samples + MI
    return MI/m